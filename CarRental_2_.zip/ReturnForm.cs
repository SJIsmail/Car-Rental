﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental
{
	public partial class ReturnForm : Form
	{
		Transaction mTransaction;
		Employee mEmployee;
		Customer mCustomer;

		Return mReturn = new Return();

		double mFees = 0.0f;

		Database mDB = new Database();

		public ReturnForm()
		{
			InitializeComponent();

			mDB.Open();
		}

		private void SearchTIDBtn_Click(object sender, EventArgs e)
		{
			if (TIDBox.Text.Length == 0 || EIDBox.Text.Length == 0)
			{
				MessageBox.Show("Neither Transaction ID nor Employee ID can be left blank.");
				return;
			}

			mTransaction = mDB.GetTransaction(TIDBox.Text);
			mEmployee = mDB.GetEmployee(EIDBox.Text);

			if (mTransaction == null)
			{
				MessageBox.Show("No transaction found with the Transaction ID specified.");
				return;
			}

			if (mEmployee == null)
			{
				MessageBox.Show("No employee found with the Employee ID specified.");
				return;
			}

			mCustomer = mDB.GetCustomer(mTransaction.FK_DriverNum);

			if (mEmployee == null)
			{
				MessageBox.Show("The Customer in the transaction is invalid.");
				return;
			}

			BIDBox.Text = mEmployee.FK_BranchID;
			BaseCostBox.Text = Convert.ToString(mTransaction.BaseCost);
			LateCostBox.Text = Convert.ToString(mTransaction.LateCost);
			ReturnCostBox.Text = Convert.ToString(mTransaction.ReturnCost);
		}

		private void CalculateBtn_Click(object sender, EventArgs e)
		{
			if (mTransaction == null || mEmployee == null)
			{
				MessageBox.Show("Specify and Search for Transaction and Employee first.");
				return;
			}

			if (mEmployee == null)
			{
				MessageBox.Show("The Customer in the transaction is invalid.");
				return;
			}

			double ContractLength = Math.Max((mTransaction.ExpectedReturnDate - mTransaction.CheckoutDate).TotalDays, 1);
			double DailyBaseCost = mTransaction.BaseCost / ContractLength;
			double BaseCost = DailyBaseCost * (DateTime.Now - mTransaction.CheckoutDate).TotalDays;

			double LateCost = 0;
			double ReturnCost = 0;

			if (mCustomer.NotGoldMember() && mTransaction.Expired())
			{
				LateCost = mTransaction.LateCost;
			}

			if (mEmployee.FK_BranchID.Equals(mTransaction.FK_BranchID) == false && mCustomer.NotGoldMember())
			{
				ReturnCost = mTransaction.ReturnCost;
			}

			mFees = BaseCost + LateCost + ReturnCost;

			FeesBox.Text = "";
			FeesBox.AppendText("Total: " + mFees.ToString("f2"));
			FeesBox.AppendText("\n");
			FeesBox.AppendText("Base: " + BaseCost.ToString("f2"));
			FeesBox.AppendText("\n");
			FeesBox.AppendText("Late: " + LateCost.ToString("f2"));
			FeesBox.AppendText("\n");
			FeesBox.AppendText("Return: " + ReturnCost.ToString("f2"));
			FeesBox.AppendText("\n");

			mReturn.FK_TransactionID = mTransaction.ID;
			mReturn.EmployeeID = mEmployee.ID;
			mReturn.BranchID = mEmployee.FK_BranchID;
			mReturn.ReturnDate = DateTime.Now;
			mReturn.Fees = mFees;
		}

		private void SaveBtn_Click(object sender, EventArgs e)
		{
			if (mTransaction == null || mEmployee == null)
			{
				MessageBox.Show("Specify and Search for Transaction and Employee first.");
				return;
			}

			if (mEmployee == null)
			{
				MessageBox.Show("The Customer in the transaction is invalid.");
				return;
			}

			mDB.WriteReturn(mReturn);
		}

		private void ResetBtn_Click(object sender, EventArgs e)
		{

		}

		private void ReturnForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			mDB.Close();
		}
	}
}