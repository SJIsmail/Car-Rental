﻿using System;

namespace CarRental
{
	class Transaction
	{
		public string ID { get; set; }
		public double BaseCost { get; set; }
		public double LateCost { get; set; }
		public double ReturnCost { get; set; }
		public DateTime CheckoutDate { get; set; }
		public DateTime ExpectedReturnDate { get; set; }
		public string FK_BranchID { get; set; }
		public string FK_EmployeeID { get; set; }
		public string FK_PlateNum { get; set; }
		public string FK_DriverNum { get; set; }

		public bool Expired()
		{
			return DateTime.Now > ExpectedReturnDate;
		}
	}
}