﻿namespace Transaction
{
	class Transaction
	{
		public int TransactionID { get; set; }
		public float LateCoast { get; set; }
		public float BaseCost { get; set; }
		public float ReturnCoast { get; set; }
	}
}