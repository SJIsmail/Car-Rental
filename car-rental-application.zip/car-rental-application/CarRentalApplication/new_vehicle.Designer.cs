﻿namespace CarRentalApplication
{
    partial class new_vehicle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.province_label = new System.Windows.Forms.Label();
            this.add_vehicle_btn = new System.Windows.Forms.Button();
            this.km_tb = new System.Windows.Forms.TextBox();
            this.model_tb = new System.Windows.Forms.TextBox();
            this.platenum_tb = new System.Windows.Forms.TextBox();
            this.colour_tb = new System.Windows.Forms.TextBox();
            this.make_tb = new System.Windows.Forms.TextBox();
            this.licence_no_label = new System.Windows.Forms.Label();
            this.l_name_label = new System.Windows.Forms.Label();
            this.building_num_label = new System.Windows.Forms.Label();
            this.street_name_label = new System.Windows.Forms.Label();
            this.city_label = new System.Windows.Forms.Label();
            this.post_code_label = new System.Windows.Forms.Label();
            this.f_name_label = new System.Windows.Forms.Label();
            this.back_button_vehicle = new System.Windows.Forms.Button();
            this.condition_cb = new System.Windows.Forms.ComboBox();
            this.branchid_cb = new System.Windows.Forms.ComboBox();
            this.year_cb = new System.Windows.Forms.ComboBox();
            this.type_cb = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // province_label
            // 
            this.province_label.AutoSize = true;
            this.province_label.Location = new System.Drawing.Point(612, 395);
            this.province_label.Name = "province_label";
            this.province_label.Size = new System.Drawing.Size(106, 25);
            this.province_label.TabIndex = 45;
            this.province_label.Text = "Branch ID";
            // 
            // add_vehicle_btn
            // 
            this.add_vehicle_btn.Location = new System.Drawing.Point(561, 585);
            this.add_vehicle_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_vehicle_btn.Name = "add_vehicle_btn";
            this.add_vehicle_btn.Size = new System.Drawing.Size(257, 85);
            this.add_vehicle_btn.TabIndex = 10;
            this.add_vehicle_btn.Text = "Add Vehicle";
            this.add_vehicle_btn.UseVisualStyleBackColor = true;
            this.add_vehicle_btn.Click += new System.EventHandler(this.add_vehicle_btn_Click);
            // 
            // km_tb
            // 
            this.km_tb.Location = new System.Drawing.Point(293, 458);
            this.km_tb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.km_tb.Name = "km_tb";
            this.km_tb.Size = new System.Drawing.Size(297, 31);
            this.km_tb.TabIndex = 8;
            // 
            // model_tb
            // 
            this.model_tb.Location = new System.Drawing.Point(293, 385);
            this.model_tb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.model_tb.Name = "model_tb";
            this.model_tb.Size = new System.Drawing.Size(297, 31);
            this.model_tb.TabIndex = 6;
            // 
            // platenum_tb
            // 
            this.platenum_tb.Location = new System.Drawing.Point(293, 178);
            this.platenum_tb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.platenum_tb.Name = "platenum_tb";
            this.platenum_tb.Size = new System.Drawing.Size(385, 31);
            this.platenum_tb.TabIndex = 1;
            // 
            // colour_tb
            // 
            this.colour_tb.Location = new System.Drawing.Point(757, 248);
            this.colour_tb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.colour_tb.Name = "colour_tb";
            this.colour_tb.Size = new System.Drawing.Size(332, 31);
            this.colour_tb.TabIndex = 3;
            // 
            // make_tb
            // 
            this.make_tb.Location = new System.Drawing.Point(293, 309);
            this.make_tb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.make_tb.Name = "make_tb";
            this.make_tb.Size = new System.Drawing.Size(297, 31);
            this.make_tb.TabIndex = 4;
            // 
            // licence_no_label
            // 
            this.licence_no_label.AutoSize = true;
            this.licence_no_label.Location = new System.Drawing.Point(137, 181);
            this.licence_no_label.Name = "licence_no_label";
            this.licence_no_label.Size = new System.Drawing.Size(148, 25);
            this.licence_no_label.TabIndex = 32;
            this.licence_no_label.Text = "Plate Number:";
            // 
            // l_name_label
            // 
            this.l_name_label.AutoSize = true;
            this.l_name_label.Location = new System.Drawing.Point(612, 251);
            this.l_name_label.Name = "l_name_label";
            this.l_name_label.Size = new System.Drawing.Size(75, 25);
            this.l_name_label.TabIndex = 31;
            this.l_name_label.Text = "Colour";
            // 
            // building_num_label
            // 
            this.building_num_label.AutoSize = true;
            this.building_num_label.Location = new System.Drawing.Point(137, 395);
            this.building_num_label.Name = "building_num_label";
            this.building_num_label.Size = new System.Drawing.Size(71, 25);
            this.building_num_label.TabIndex = 30;
            this.building_num_label.Text = "Model";
            // 
            // street_name_label
            // 
            this.street_name_label.AutoSize = true;
            this.street_name_label.Location = new System.Drawing.Point(612, 316);
            this.street_name_label.Name = "street_name_label";
            this.street_name_label.Size = new System.Drawing.Size(58, 25);
            this.street_name_label.TabIndex = 29;
            this.street_name_label.Text = "Year";
            // 
            // city_label
            // 
            this.city_label.AutoSize = true;
            this.city_label.Location = new System.Drawing.Point(137, 465);
            this.city_label.Name = "city_label";
            this.city_label.Size = new System.Drawing.Size(43, 25);
            this.city_label.TabIndex = 28;
            this.city_label.Text = "Km";
            // 
            // post_code_label
            // 
            this.post_code_label.AutoSize = true;
            this.post_code_label.Location = new System.Drawing.Point(619, 468);
            this.post_code_label.Name = "post_code_label";
            this.post_code_label.Size = new System.Drawing.Size(103, 25);
            this.post_code_label.TabIndex = 27;
            this.post_code_label.Text = "Condition";
            // 
            // f_name_label
            // 
            this.f_name_label.AutoSize = true;
            this.f_name_label.Location = new System.Drawing.Point(137, 320);
            this.f_name_label.Name = "f_name_label";
            this.f_name_label.Size = new System.Drawing.Size(65, 25);
            this.f_name_label.TabIndex = 26;
            this.f_name_label.Text = "Make";
            // 
            // back_button_vehicle
            // 
            this.back_button_vehicle.Location = new System.Drawing.Point(72, 61);
            this.back_button_vehicle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.back_button_vehicle.Name = "back_button_vehicle";
            this.back_button_vehicle.Size = new System.Drawing.Size(119, 55);
            this.back_button_vehicle.TabIndex = 25;
            this.back_button_vehicle.Text = "< Back";
            this.back_button_vehicle.UseVisualStyleBackColor = true;
            this.back_button_vehicle.Click += new System.EventHandler(this.back_button_vehicle_Click);
            // 
            // condition_cb
            // 
            this.condition_cb.FormattingEnabled = true;
            this.condition_cb.Location = new System.Drawing.Point(757, 458);
            this.condition_cb.Margin = new System.Windows.Forms.Padding(4);
            this.condition_cb.Name = "condition_cb";
            this.condition_cb.Size = new System.Drawing.Size(216, 33);
            this.condition_cb.TabIndex = 9;
            // 
            // branchid_cb
            // 
            this.branchid_cb.FormattingEnabled = true;
            this.branchid_cb.Location = new System.Drawing.Point(757, 385);
            this.branchid_cb.Margin = new System.Windows.Forms.Padding(4);
            this.branchid_cb.Name = "branchid_cb";
            this.branchid_cb.Size = new System.Drawing.Size(332, 33);
            this.branchid_cb.TabIndex = 7;
            // 
            // year_cb
            // 
            this.year_cb.FormattingEnabled = true;
            this.year_cb.Location = new System.Drawing.Point(757, 310);
            this.year_cb.Margin = new System.Windows.Forms.Padding(4);
            this.year_cb.Name = "year_cb";
            this.year_cb.Size = new System.Drawing.Size(332, 33);
            this.year_cb.TabIndex = 5;
            // 
            // type_cb
            // 
            this.type_cb.FormattingEnabled = true;
            this.type_cb.Location = new System.Drawing.Point(293, 240);
            this.type_cb.Margin = new System.Windows.Forms.Padding(4);
            this.type_cb.Name = "type_cb";
            this.type_cb.Size = new System.Drawing.Size(297, 33);
            this.type_cb.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(143, 249);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 25);
            this.label1.TabIndex = 50;
            this.label1.Text = "Type";
            // 
            // new_vehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1347, 768);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.type_cb);
            this.Controls.Add(this.year_cb);
            this.Controls.Add(this.branchid_cb);
            this.Controls.Add(this.condition_cb);
            this.Controls.Add(this.province_label);
            this.Controls.Add(this.add_vehicle_btn);
            this.Controls.Add(this.km_tb);
            this.Controls.Add(this.model_tb);
            this.Controls.Add(this.platenum_tb);
            this.Controls.Add(this.colour_tb);
            this.Controls.Add(this.make_tb);
            this.Controls.Add(this.licence_no_label);
            this.Controls.Add(this.l_name_label);
            this.Controls.Add(this.building_num_label);
            this.Controls.Add(this.street_name_label);
            this.Controls.Add(this.city_label);
            this.Controls.Add(this.post_code_label);
            this.Controls.Add(this.f_name_label);
            this.Controls.Add(this.back_button_vehicle);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "new_vehicle";
            this.Text = "Add New Vehicle";
            this.Load += new System.EventHandler(this.new_vehicle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label province_label;
        private System.Windows.Forms.Button add_vehicle_btn;
        private System.Windows.Forms.TextBox km_tb;
        private System.Windows.Forms.TextBox model_tb;
        private System.Windows.Forms.TextBox platenum_tb;
        private System.Windows.Forms.TextBox colour_tb;
        private System.Windows.Forms.TextBox make_tb;
        private System.Windows.Forms.Label licence_no_label;
        private System.Windows.Forms.Label l_name_label;
        private System.Windows.Forms.Label building_num_label;
        private System.Windows.Forms.Label street_name_label;
        private System.Windows.Forms.Label city_label;
        private System.Windows.Forms.Label post_code_label;
        private System.Windows.Forms.Label f_name_label;
        private System.Windows.Forms.Button back_button_vehicle;
        private System.Windows.Forms.ComboBox condition_cb;
        private System.Windows.Forms.ComboBox branchid_cb;
        private System.Windows.Forms.ComboBox year_cb;
        private System.Windows.Forms.ComboBox type_cb;
        private System.Windows.Forms.Label label1;
    }
}