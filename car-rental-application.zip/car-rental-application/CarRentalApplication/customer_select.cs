﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class customer_select : Form
    {
        public database db;
        DataRow row = null;
        DataRow rowSelect = null;
        string custID = null;
        DataTable DT = new DataTable();
        string searchField = null;
        string emptyQuery = @"select * from Customer";
        public customer_select(database t)
        {
            db = t;
            InitializeComponent();
            this.Height = 530;
            this.Width = 885;
            this.CustomerTable.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.CustomerTable.MultiSelect = false;
            db.query(emptyQuery);
            DT.Load(db.myReader);
            CustomerTable.DataSource = DT;
            db.myReader.Close(); //resetting reader
        }

        private void LoadCustTable_Click(object sender, EventArgs e)
        {
            if (CustDataType.Text == "")
            {
                db.query(emptyQuery);
                DT.Clear();
                DT.Load(db.myReader);
                CustomerTable.DataSource = DT;
                db.myReader.Close(); //resetting reader
            }
            else if ((UserCustSearch.Text != "") && (CustDataType.Text != ""))
            {
                if (CustDataType.Text == "First Name")
                {
                    searchField = "f_name";
                }
                if (CustDataType.Text == "Last Name")
                {
                    searchField = "l_name";
                }
                if (CustDataType.Text == "Phone Number")
                {
                    searchField = "phone_num";
                }
                if (CustDataType.Text == "Driver's Licence Number")
                {
                    searchField = "driver_num";
                }

                string queryStr = @"select * from Customer where " + searchField + " = '" + UserCustSearch.Text + "';";
                db.query(queryStr);
                DT.Clear();
                DT.Load(db.myReader);
                CustomerTable.DataSource = DT;
                db.myReader.Close();

            }
            else
            {
                MessageBox.Show("Search Invalid");
            }
             //resetting reader
            //@" string on multiple lines"  
            //db.(QUERYSTRING)querey, saved as string
            //DataTable.Load(DB.myReader)
            //DatagridView.DataSource = temp

            /*Query, load query in DT, set datagridview source to DT*/
        }

        private void Customers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            rowSelect = ((DataRowView)CustomerTable.CurrentRow.DataBoundItem).Row;
            custID = rowSelect["driver_num"].ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CreateNewCustomer_Click(object sender, EventArgs e)
        {
            new_customer createCust = new new_customer(db);
            this.Hide();
            createCust.ShowDialog();
            db.query(emptyQuery);
            DT.Clear();
            DT.Load(db.myReader);
            CustomerTable.DataSource = DT;
            db.myReader.Close(); //resetting reader
            this.Show();
        }

        private void CreateReservation_Click(object sender, EventArgs e)
        {
            if (custID != null)
            {
                create_reservation createReser = new create_reservation(db, custID);
                this.Hide();
                createReser.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Please Select a Customer Before Preceeding");
            }
        }

        private void edit_customer_Click(object sender, EventArgs e)
        {
            if (custID != null)
            {
                row = ((DataRowView)CustomerTable.CurrentRow.DataBoundItem).Row;
                edit_customer editCust = new edit_customer(db, row);
                this.Hide();
                editCust.ShowDialog();
                db.query(emptyQuery);
                DT.Clear();
                DT.Load(db.myReader);
                CustomerTable.DataSource = DT;
                db.myReader.Close(); //resetting reader
                this.Show();
            }
            else
            {
                MessageBox.Show("Please Select a Customer Before Preceeding");
            }
        }

        private void backButton_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
