﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class create_reservation : Form
    {
        public database db;
        DataRow row = null;
        DateTime return_day;
        string transaction_id = null;
        double base_cost;
        double late_cost;
        double return_cost;
        string branch_id = null;
        string emp_id = null;
        string plate_num = null;
        string driver_num = null;
        public create_reservation(database t, string ID)
        {
            db = t;
            driver_num = ID;
            InitializeComponent();
            this.Height = 530;
            this.Width = 885;
            this.VehicleTable.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.VehicleTable.MultiSelect = false;
        }

        private void SearchVehicles_Click(object sender, EventArgs e)
        {
            DataTable DT = new DataTable();
            if (EmployeeID.Text != "Employee ID")
            {
                try
                {
                    //using employee ID to get branch ID
                    string queryStr1 = @"select branch_id 
                                         from Employee 
                                         where emp_id = '" + EmployeeID.Text + "';";
                    db.query(queryStr1);
                    db.myReader.Read();
                    branch_id = db.myReader["branch_id"].ToString();
                    db.myReader.Close(); //resetting reader

                    string queryStr2 = @"select plate_num,kms,make,model,[year],colour,condition,[type_id] 
                                         from Vehicle V join Employee E on E.branch_id=V.branch_id 
                                         where condition > 0 and V.branch_id = '" + branch_id + "' and emp_id = '" +
                                         EmployeeID.Text + "';";
                    db.query(queryStr2);
                    DT.Load(db.myReader);
                    VehicleTable.DataSource = DT;
                }
                catch
                {
                    MessageBox.Show("Invalid Employee ID");
                    db.myReader.Close(); //resetting reader
                } 
            }
            else
            {
                MessageBox.Show("Enter Employee ID");
            }
        }

        private void VehicleTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            row = ((DataRowView)VehicleTable.CurrentRow.DataBoundItem).Row;
            plate_num = row["plate_num"].ToString();
        }

        private void Finalize_Click(object sender, EventArgs e)
        {
            DateTime check_out = DateTime.Today;
            try
            {
                return_day = DateTime.Parse(YYYY.Text + '-' + MM.Text + '-' + DD.Text);
                if (((return_day - check_out).TotalDays) < 1)
                {
                    //forcing error to make code fall into the catch statement to display the error message
                    var error = int.Parse("aaaa");
                }
                try
                {
                    //current transaction ID is derived from lastest transaction ID
                    string query = @"select max(convert(INT,SUBSTRING(transaction_id, 1,  LEN(transaction_id)))) as temp 
                                 from Rental_Transaction";
                    db.query(query);
                    db.myReader.Read();
                    int trans_id = int.Parse(db.myReader["temp"].ToString());
                    trans_id += 1;
                    db.myReader.Close(); //resetting reader
                    transaction_id = trans_id.ToString().PadLeft(10, '0');//padding transaction_id 10 characters


                    //base_cost
                    query = @"select VT.rental_fee 
                          from Vehicle V join Vehicle_Type VT on VT.[type_id]=V.[type_id]
                          where V.plate_num = '" + plate_num + "';";
                    db.query(query);
                    db.myReader.Read();
                    base_cost = double.Parse(db.myReader["rental_fee"].ToString());

                    int span = (Int32)(return_day - check_out).TotalDays;
                    base_cost *= span;
                    db.myReader.Close(); //resetting reader

                    //late_cost
                    query = @"select VT.late_fee 
                          from Vehicle V join Vehicle_Type VT on VT.[type_id]=V.[type_id]
                          where V.plate_num = '" + plate_num + "';";
                    db.query(query);
                    db.myReader.Read();
                    late_cost = double.Parse(db.myReader["late_fee"].ToString());
                    db.myReader.Close(); //resetting reader

                    //return_cost
                    query = @"select VT.return_fee
                          from Vehicle V join Vehicle_Type VT on VT.[type_id]=V.[type_id]
                          where V.plate_num = '" + plate_num + "';";
                    db.query(query);
                    db.myReader.Read();
                    return_cost = double.Parse(db.myReader["return_fee"].ToString());
                    db.myReader.Close(); //resetting reader


                    //current date taken for reservation creation
                    string check_out_date = DateTime.Today.ToString("yyyy-MM-dd");

                    //return date for the reservation
                    string expected_return = YYYY.Text + '-' + MM.Text + '-' + DD.Text;

                    //branch_id is already found previously

                    //emp_id
                    emp_id = EmployeeID.Text;

                    //plate_num is already found previously from selecting vehicle

                    //driver_num is passed from previous form

                    string insert = $"insert into Rental_Transaction values('{transaction_id}',{base_cost},{late_cost},{return_cost},TRY_CONVERT(DATE, '{check_out_date}'),TRY_CONVERT(DATE, '{expected_return}'),'{branch_id}','{emp_id}','{plate_num}','{driver_num}');";
                    db.insert(insert);
                    string command = @"Update Vehicle set condition=6 where plate_num = '" + plate_num + "';";
                    db.insert(command);
                    MessageBox.Show($"Transaction ID {transaction_id}\nAmount owing for {span} day rental:\n\t${base_cost}\n\nAwait payment and close window once finished");
                    this.Close();
                    MessageBox.Show($"Transaction ID = {transaction_id}\nRental Charge = {base_cost}\nPossible Late Charge = {late_cost}\nPossible Wrong Branch Return Upcharge = {return_cost}\nDate of Rental: {check_out_date}\nRental Due Back on: {expected_return}\nBranch: {branch_id} Employee: {emp_id}\nCar: {plate_num}\nCustomer: {driver_num}");
                }
                catch
                {
                    MessageBox.Show("Invalid Entry, Review Reservation Details and Re-finalize");
                    db.myReader.Close(); //resetting reader
                }
            }
            catch
            {
                MessageBox.Show("Invalid Return Date, Review and Re-finalize");
            }
        }
    }
}
