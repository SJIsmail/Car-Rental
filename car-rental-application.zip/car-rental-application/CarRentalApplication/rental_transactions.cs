﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class rental_transactions : Form
    {
        public database db;
        public string check = "";
        DataRow rowSelect = null; // Warning says this doesn't get used, can we get rid of it?
        DataTable DT = new DataTable();
        string queryStr = @"select RT.transaction_id,base_cost,late_cost,return_cost,check_out_date,
                            expected_return,RT.branch_id as rental_branch,RT.emp_id as created_by,
                            plate_num, driver_num, R.emp_id as returned_by, R.branch_id as return_branch,
                            return_date, fees_paid
                            from Rental_Transaction RT left join [Returns] R 
                            on RT.transaction_id=R.transaction_id;";
        public rental_transactions(database t)
        {
            db=t;
            InitializeComponent();
            closeTransaction.Visible = false;
            this.Height = 530;
            this.Width = 885;
            this.TransactionTable.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.TransactionTable.MultiSelect = false;
            db.query(queryStr);
            DT.Load(db.myReader);
            TransactionTable.DataSource = DT;
            db.myReader.Close();
        }

        private void TransactionTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            rowSelect = ((DataRowView)TransactionTable.CurrentRow.DataBoundItem).Row;
            check = rowSelect["transaction_id"].ToString();
            if (rowSelect["return_branch"].ToString() == "")
            {
                closeTransaction.Visible = true;
            }
            else
            {
                closeTransaction.Visible = false;
            }
        }

        private void edit_Click(object sender, EventArgs e)
        {
            if (check != "")
            {
                edit_rental editRental = new edit_rental(db, rowSelect);
                this.Hide();
                editRental.ShowDialog();
                db.query(queryStr);
                DT.Clear();
                DT.Load(db.myReader);
                TransactionTable.DataSource = DT;
                db.myReader.Close(); //resetting reader
                this.Show();
                //reseting check to prevent crash after switching between editting and closing transactions
                check = "";
                closeTransaction.Visible = false;
            }
            else
            {
                MessageBox.Show("Select a Reservation to Edit");
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void closeTransaction_Click(object sender, EventArgs e)
        {
            if (check != "")
            {
                close_transaction closeRental = new close_transaction(db, rowSelect);
                this.Hide();
                closeRental.ShowDialog();
                db.query(queryStr);
                DT.Clear();
                DT.Load(db.myReader);
                TransactionTable.DataSource = DT;
                db.myReader.Close(); //resetting reader
                this.Show();
                //reseting check to prevent crash after switching between editting and closing transactions
                check = "";
                closeTransaction.Visible = false;
            }
            else
            {
                MessageBox.Show("Select a Reservation to Close");
            }
        }
    }
}
