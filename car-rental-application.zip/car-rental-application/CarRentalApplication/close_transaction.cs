﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class close_transaction : Form
    {
        public database db;
        DataRow row = null;
        DateTime testDate;
        string date = null;
        double span = 0;
        string status = null;
        bool pays_return_fee = true;
        bool pays_late_fee = true;
        string check;
        int checkNum;

        public close_transaction(database t, DataRow rowSelect)
        {
            row = rowSelect;
            db = t;
            InitializeComponent();

            this.Height = 530;
            this.Width = 885;
            //setting all text boxes to original values pulled from previous form
            transactionID.Text = row["transaction_id"].ToString();
            baseCost.Text = String.Format("{0:0.00}", Convert.ToDouble(row["base_cost"]));
            lateCost.Text = String.Format("{0:0.00}", Convert.ToDouble(row["late_cost"]));
            returnCost.Text = String.Format("{0:0.00}", Convert.ToDouble(row["return_cost"]));
            checkOutDate.Text = ((DateTime)row["check_out_date"]).ToString("yyyy-MM-dd");
            expectedReturn.Text = ((DateTime)row["expected_return"]).ToString("yyyy-MM-dd");
            RTbranchID.Text = row["rental_branch"].ToString();
            RTempID.Text = row["created_by"].ToString();
            plateNum.Text = row["plate_num"].ToString();
            driverNum.Text = row["driver_num"].ToString();

            //reading customer status to determine if fees will be charged
            db.query($"select status_id from Customer where driver_num = '{driverNum.Text}'");
            db.myReader.Read();
            status = db.myReader["status_id"].ToString();
            db.myReader.Close(); //resetting reader

            //grabbing status bit type fields to see what types of fees customer is exempt from
            db.query($"select pays_return_fee, pays_late_fee from Membership where status_id = '{status}'");
            db.myReader.Read();
            pays_return_fee = Convert.ToBoolean(db.myReader["pays_return_fee"]);
            pays_late_fee = Convert.ToBoolean(db.myReader["pays_late_fee"]);
            db.myReader.Close(); //resetting reader

            //setting return date initially today's date and then setting late cost accordingly
            returnDate.Text = (DateTime.Today).ToString("yyyy-MM-dd");
            span = (Int32)(testDate - (DateTime.Parse(expectedReturn.Text))).TotalDays;
            double cost = double.Parse(lateCost.Text);
            cost *= (double)span;
            if (cost > 0 && pays_late_fee)
            {
                feesDue.Text = (cost).ToString();
            }
            else
            {
                feesDue.Text = "0.00";
            }

        }

        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                //error checking Employee ID
                check = RempID.Text;
                if ( (check.Length != 4) || !(check.All(Char.IsDigit)))
                {
                    MessageBox.Show("Check Employee ID");
                }
                //error checking Branch ID
                check = RbranchID.Text;
                if ((check.Length != 3) || !(check.All(Char.IsDigit)))
                {
                    MessageBox.Show("Check Branch ID");
                }

                //error checking Return Date
                check = feesDue.Text;
                if (check == "")
                {
                    MessageBox.Show("Check Return Date");
                }

                //error checking Condition
                double total = double.Parse(retrunFeeBox.Text);
                total += double.Parse(feesDue.Text);
                if (!pays_return_fee && !pays_late_fee)
                {
                    total = 0;
                }
                string commandInsert = $"Insert into [Returns] values ('{transactionID.Text}' , '{RempID.Text}', '{RbranchID.Text}', TRY_CONVERT(DATE, '{returnDate.Text}'), {total});";
                db.insert(commandInsert);
                if (total > 0)
                {
                    MessageBox.Show($"AMOUNT DUE: ${total}\n\n Take payment and please close this window to finalize this transaction");
                }
                MessageBox.Show(@"Rental Transaction Successfully Closed"); //record updated
                // UPDATE STATUS HERE ** Done
                update_status toGold = new update_status();
                toGold.update(db, driverNum.Text);
                string command = @"Update Vehicle set condition=" + returnCondition.Text +
                    ", branch_id='" + RbranchID.Text + "' where plate_num = '" + plateNum.Text + "';";
                db.insert(command);
                this.Close(); //exit window
            }
            catch
            {
                MessageBox.Show("Invalid Return Transaction Information");
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void returnDate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                date = returnDate.Text;
                if ((date.Length == 10) && pays_late_fee)
                {
                    testDate = Convert.ToDateTime(returnDate.Text);
                    span = (testDate - (DateTime.Parse(expectedReturn.Text))).TotalDays;
                    double cost = double.Parse(lateCost.Text);
                    cost *= (double)span;
                    if (cost > 0)
                    {
                        feesDue.Text = (cost).ToString();
                    }
                    else
                    {
                        feesDue.Text = "0.00";
                    }
                }
                else
                {
                    feesDue.Text = "";
                }
            }
            catch
            {
                feesDue.Text = "";
            }
            //IF TEXT = VALID DATE, CALCULATE FEEES DUE, IF NOT DONT DO ANYTHING
        }

        private void RbranchID_TextChanged(object sender, EventArgs e)
        {
            // if branch changed, add to fees
            string bidLength = RbranchID.Text;
            if (bidLength.Length > 2 && bidLength.Length < 4)
            {
                if (RbranchID.Text != RTbranchID.Text && pays_return_fee)
                {
                    retrunFeeBox.Text = returnCost.Text;
                }
                else
                {
                    retrunFeeBox.Text = "0.00";
                }
            }
            else
            {
                retrunFeeBox.Text = "";
            }

        }
    }
}