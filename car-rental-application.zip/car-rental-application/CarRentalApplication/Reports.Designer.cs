﻿namespace CarRentalApplication
{
    partial class reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.reportPage1 = new System.Windows.Forms.TabPage();
            this.level_select = new System.Windows.Forms.ComboBox();
            this.ReportButton1 = new System.Windows.Forms.Button();
            this.ReportText1 = new System.Windows.Forms.TextBox();
            this.reportTable1 = new System.Windows.Forms.DataGridView();
            this.reportPage2 = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.reportTable2 = new System.Windows.Forms.DataGridView();
            this.reportPage3 = new System.Windows.Forms.TabPage();
            this.reportTable3 = new System.Windows.Forms.DataGridView();
            this.tabControl.SuspendLayout();
            this.reportPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportTable1)).BeginInit();
            this.reportPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportTable2)).BeginInit();
            this.reportPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportTable3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.reportPage1);
            this.tabControl.Controls.Add(this.reportPage2);
            this.tabControl.Controls.Add(this.reportPage3);
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1744, 930);
            this.tabControl.TabIndex = 0;
            // 
            // reportPage1
            // 
            this.reportPage1.Controls.Add(this.level_select);
            this.reportPage1.Controls.Add(this.ReportButton1);
            this.reportPage1.Controls.Add(this.ReportText1);
            this.reportPage1.Controls.Add(this.reportTable1);
            this.reportPage1.Location = new System.Drawing.Point(8, 39);
            this.reportPage1.Name = "reportPage1";
            this.reportPage1.Padding = new System.Windows.Forms.Padding(3);
            this.reportPage1.Size = new System.Drawing.Size(1728, 883);
            this.reportPage1.TabIndex = 0;
            this.reportPage1.Text = "Customers by Address";
            this.reportPage1.UseVisualStyleBackColor = true;
            // 
            // level_select
            // 
            this.level_select.FormattingEnabled = true;
            this.level_select.Items.AddRange(new object[] {
            "Gold",
            "Bronze",
            "Both Bronze AND Gold"});
            this.level_select.Location = new System.Drawing.Point(439, 83);
            this.level_select.Name = "level_select";
            this.level_select.Size = new System.Drawing.Size(310, 33);
            this.level_select.TabIndex = 3;
            this.level_select.Text = "Membership level";
            this.level_select.SelectedIndexChanged += new System.EventHandler(this.level_select_SelectedIndexChanged);
            // 
            // ReportButton1
            // 
            this.ReportButton1.Location = new System.Drawing.Point(891, 77);
            this.ReportButton1.Name = "ReportButton1";
            this.ReportButton1.Size = new System.Drawing.Size(246, 70);
            this.ReportButton1.TabIndex = 2;
            this.ReportButton1.Text = "Go";
            this.ReportButton1.UseVisualStyleBackColor = true;
            this.ReportButton1.Click += new System.EventHandler(this.ReportButton1_Click);
            // 
            // ReportText1
            // 
            this.ReportText1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportText1.Location = new System.Drawing.Point(79, 17);
            this.ReportText1.Name = "ReportText1";
            this.ReportText1.ReadOnly = true;
            this.ReportText1.Size = new System.Drawing.Size(1532, 38);
            this.ReportText1.TabIndex = 1;
            this.ReportText1.Text = "This screen generates a report showing the number of Customers organized by their" +
    " Postal Code and their membership status. ";
            this.ReportText1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // reportTable1
            // 
            this.reportTable1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reportTable1.Location = new System.Drawing.Point(0, 174);
            this.reportTable1.Name = "reportTable1";
            this.reportTable1.RowTemplate.Height = 33;
            this.reportTable1.Size = new System.Drawing.Size(1728, 708);
            this.reportTable1.TabIndex = 0;
            this.reportTable1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.reportTable1_CellContentClick);
            // 
            // reportPage2
            // 
            this.reportPage2.Controls.Add(this.textBox1);
            this.reportPage2.Controls.Add(this.reportTable2);
            this.reportPage2.Location = new System.Drawing.Point(8, 39);
            this.reportPage2.Name = "reportPage2";
            this.reportPage2.Padding = new System.Windows.Forms.Padding(3);
            this.reportPage2.Size = new System.Drawing.Size(1728, 883);
            this.reportPage2.TabIndex = 1;
            this.reportPage2.Text = "PLACEHODER";
            this.reportPage2.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(201, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(300, 31);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // reportTable2
            // 
            this.reportTable2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reportTable2.Location = new System.Drawing.Point(0, 174);
            this.reportTable2.Name = "reportTable2";
            this.reportTable2.RowTemplate.Height = 33;
            this.reportTable2.Size = new System.Drawing.Size(1728, 709);
            this.reportTable2.TabIndex = 1;
            this.reportTable2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.reportTable2_CellContentClick);
            // 
            // reportPage3
            // 
            this.reportPage3.Controls.Add(this.reportTable3);
            this.reportPage3.Location = new System.Drawing.Point(8, 39);
            this.reportPage3.Name = "reportPage3";
            this.reportPage3.Size = new System.Drawing.Size(1728, 883);
            this.reportPage3.TabIndex = 2;
            this.reportPage3.Text = "PLACEHODER";
            this.reportPage3.UseVisualStyleBackColor = true;
            // 
            // reportTable3
            // 
            this.reportTable3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reportTable3.Location = new System.Drawing.Point(0, 174);
            this.reportTable3.Name = "reportTable3";
            this.reportTable3.RowTemplate.Height = 33;
            this.reportTable3.Size = new System.Drawing.Size(1728, 709);
            this.reportTable3.TabIndex = 1;
            // 
            // reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1744, 929);
            this.Controls.Add(this.tabControl);
            this.Name = "reports";
            this.Text = "Reports";
            this.tabControl.ResumeLayout(false);
            this.reportPage1.ResumeLayout(false);
            this.reportPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportTable1)).EndInit();
            this.reportPage2.ResumeLayout(false);
            this.reportPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportTable2)).EndInit();
            this.reportPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.reportTable3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage reportPage1;
        private System.Windows.Forms.TabPage reportPage2;
        private System.Windows.Forms.TabPage reportPage3;
        private System.Windows.Forms.DataGridView reportTable1;
        private System.Windows.Forms.DataGridView reportTable2;
        private System.Windows.Forms.DataGridView reportTable3;
        private System.Windows.Forms.TextBox ReportText1;
        private System.Windows.Forms.Button ReportButton1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox level_select;
    }
}