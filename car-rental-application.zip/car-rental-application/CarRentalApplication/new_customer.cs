﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class new_customer : Form
    {
        public database db;
        public new_customer(database t)
        {
            InitializeComponent();
            db = t;
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cust_submit_Click(object sender, EventArgs e)
        {
            try
            {
                string today = DateTime.Today.ToString("yyyy-MM-dd");
                string command = @"insert into customer values ('" + license_no.Text.ToUpper() + "','" + "BRONZE" +
                    "','" + f_name.Text.ToUpper() + "','" + l_name.Text.ToUpper() + "','" + building_num.Text.ToUpper() + "','" + 
                    street_name.Text.ToUpper() + "','" + street_type.Text.ToUpper() + "','" + city.Text.ToUpper() + "','" + province.Text.ToUpper() + "','" 
                    + post_code.Text.ToUpper() + "','" + phone_num.Text + "'," + "TRY_CONVERT(DATE, '" + today + "')," + "TRY_CONVERT(DATE, '" + today + "')); ";
                db.insert(command);
                MessageBox.Show("Customer Successfully Created");
                this.Close();
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.ToString(), "Input appears to be in incorrect format, review and try again. ");
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void license_no_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
