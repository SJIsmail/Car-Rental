﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class login : Form
    {
        public database db;
        public login()
        {
            InitializeComponent();
            password.PasswordChar = '*';
        }

        private void login_Click(object sender, EventArgs e)
        {
            try
            {
                db = new database(username.Text, password.Text);
                main_screen main = new main_screen(db);
                this.Hide();
                main.ShowDialog();
                this.Close();
            }
            catch
            {
                MessageBox.Show("Invalid login credentials");
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void username_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
