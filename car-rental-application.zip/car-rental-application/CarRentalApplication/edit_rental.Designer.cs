﻿namespace CarRentalApplication
{
    partial class edit_rental
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.baseCost = new System.Windows.Forms.TextBox();
            this.lateCost = new System.Windows.Forms.TextBox();
            this.returnCost = new System.Windows.Forms.TextBox();
            this.checkOutDate = new System.Windows.Forms.TextBox();
            this.expectedReturn = new System.Windows.Forms.TextBox();
            this.RTbranchID = new System.Windows.Forms.TextBox();
            this.RTempID = new System.Windows.Forms.TextBox();
            this.plateNum = new System.Windows.Forms.TextBox();
            this.driverNum = new System.Windows.Forms.TextBox();
            this.RempID = new System.Windows.Forms.TextBox();
            this.RbranchID = new System.Windows.Forms.TextBox();
            this.returnDate = new System.Windows.Forms.TextBox();
            this.feesPaid = new System.Windows.Forms.TextBox();
            this.transactionID = new System.Windows.Forms.Label();
            this.label12341342344 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Imsotiredoflabels = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Save = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.deleteRental = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // baseCost
            // 
            this.baseCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.baseCost.Location = new System.Drawing.Point(380, 186);
            this.baseCost.Name = "baseCost";
            this.baseCost.Size = new System.Drawing.Size(344, 56);
            this.baseCost.TabIndex = 0;
            // 
            // lateCost
            // 
            this.lateCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lateCost.Location = new System.Drawing.Point(380, 269);
            this.lateCost.Name = "lateCost";
            this.lateCost.Size = new System.Drawing.Size(344, 56);
            this.lateCost.TabIndex = 1;
            // 
            // returnCost
            // 
            this.returnCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnCost.Location = new System.Drawing.Point(380, 359);
            this.returnCost.Name = "returnCost";
            this.returnCost.Size = new System.Drawing.Size(344, 56);
            this.returnCost.TabIndex = 2;
            // 
            // checkOutDate
            // 
            this.checkOutDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOutDate.Location = new System.Drawing.Point(380, 441);
            this.checkOutDate.Name = "checkOutDate";
            this.checkOutDate.Size = new System.Drawing.Size(344, 56);
            this.checkOutDate.TabIndex = 3;
            // 
            // expectedReturn
            // 
            this.expectedReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expectedReturn.Location = new System.Drawing.Point(380, 519);
            this.expectedReturn.Name = "expectedReturn";
            this.expectedReturn.Size = new System.Drawing.Size(344, 56);
            this.expectedReturn.TabIndex = 4;
            // 
            // RTbranchID
            // 
            this.RTbranchID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RTbranchID.Location = new System.Drawing.Point(380, 596);
            this.RTbranchID.Name = "RTbranchID";
            this.RTbranchID.Size = new System.Drawing.Size(344, 56);
            this.RTbranchID.TabIndex = 5;
            // 
            // RTempID
            // 
            this.RTempID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RTempID.Location = new System.Drawing.Point(380, 668);
            this.RTempID.Name = "RTempID";
            this.RTempID.Size = new System.Drawing.Size(344, 56);
            this.RTempID.TabIndex = 6;
            // 
            // plateNum
            // 
            this.plateNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plateNum.Location = new System.Drawing.Point(380, 747);
            this.plateNum.Name = "plateNum";
            this.plateNum.Size = new System.Drawing.Size(344, 56);
            this.plateNum.TabIndex = 7;
            // 
            // driverNum
            // 
            this.driverNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.driverNum.Location = new System.Drawing.Point(380, 824);
            this.driverNum.Name = "driverNum";
            this.driverNum.Size = new System.Drawing.Size(344, 56);
            this.driverNum.TabIndex = 8;
            // 
            // RempID
            // 
            this.RempID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RempID.Location = new System.Drawing.Point(1076, 189);
            this.RempID.Name = "RempID";
            this.RempID.Size = new System.Drawing.Size(344, 56);
            this.RempID.TabIndex = 9;
            // 
            // RbranchID
            // 
            this.RbranchID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbranchID.Location = new System.Drawing.Point(1076, 272);
            this.RbranchID.Name = "RbranchID";
            this.RbranchID.Size = new System.Drawing.Size(344, 56);
            this.RbranchID.TabIndex = 10;
            // 
            // returnDate
            // 
            this.returnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnDate.Location = new System.Drawing.Point(1076, 362);
            this.returnDate.Name = "returnDate";
            this.returnDate.Size = new System.Drawing.Size(344, 56);
            this.returnDate.TabIndex = 11;
            // 
            // feesPaid
            // 
            this.feesPaid.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feesPaid.Location = new System.Drawing.Point(1076, 444);
            this.feesPaid.Name = "feesPaid";
            this.feesPaid.Size = new System.Drawing.Size(344, 56);
            this.feesPaid.TabIndex = 12;
            // 
            // transactionID
            // 
            this.transactionID.AutoSize = true;
            this.transactionID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transactionID.Location = new System.Drawing.Point(724, 27);
            this.transactionID.Name = "transactionID";
            this.transactionID.Size = new System.Drawing.Size(0, 51);
            this.transactionID.TabIndex = 15;
            // 
            // label12341342344
            // 
            this.label12341342344.AutoSize = true;
            this.label12341342344.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12341342344.Location = new System.Drawing.Point(12, 194);
            this.label12341342344.Name = "label12341342344";
            this.label12341342344.Size = new System.Drawing.Size(221, 51);
            this.label12341342344.TabIndex = 16;
            this.label12341342344.Text = "Base Cost";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 275);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 51);
            this.label3.TabIndex = 18;
            this.label3.Text = "Late Cost";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 365);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(251, 51);
            this.label4.TabIndex = 19;
            this.label4.Text = "Return Cost";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 447);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(327, 51);
            this.label5.TabIndex = 20;
            this.label5.Text = "Check Out Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 529);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(343, 51);
            this.label6.TabIndex = 21;
            this.label6.Text = "Expected Return";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 604);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(213, 51);
            this.label7.TabIndex = 22;
            this.label7.Text = "Branch ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 755);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(285, 51);
            this.label8.TabIndex = 23;
            this.label8.Text = "Plate Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(789, 189);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(269, 51);
            this.label9.TabIndex = 24;
            this.label9.Text = "Employee ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 673);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(269, 51);
            this.label10.TabIndex = 25;
            this.label10.Text = "Employee ID";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 829);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(301, 51);
            this.label11.TabIndex = 26;
            this.label11.Text = "Driver Number";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(789, 272);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(213, 51);
            this.label12.TabIndex = 27;
            this.label12.Text = "Branch ID";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(789, 362);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(253, 51);
            this.label13.TabIndex = 28;
            this.label13.Text = "Return Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(789, 444);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(216, 51);
            this.label14.TabIndex = 29;
            this.label14.Text = "Fees Paid";
            // 
            // Imsotiredoflabels
            // 
            this.Imsotiredoflabels.AutoSize = true;
            this.Imsotiredoflabels.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Imsotiredoflabels.Location = new System.Drawing.Point(371, 95);
            this.Imsotiredoflabels.Name = "Imsotiredoflabels";
            this.Imsotiredoflabels.Size = new System.Drawing.Size(384, 51);
            this.Imsotiredoflabels.TabIndex = 30;
            this.Imsotiredoflabels.Text = "Rental Transaction";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1055, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(388, 51);
            this.label1.TabIndex = 31;
            this.label1.Text = "Return Transaction";
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(907, 556);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(513, 180);
            this.Save.TabIndex = 32;
            this.Save.Text = "Save Changes";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(12, 12);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(125, 59);
            this.backButton.TabIndex = 33;
            this.backButton.Text = "< Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // deleteRental
            // 
            this.deleteRental.Location = new System.Drawing.Point(1245, 800);
            this.deleteRental.Name = "deleteRental";
            this.deleteRental.Size = new System.Drawing.Size(175, 72);
            this.deleteRental.TabIndex = 34;
            this.deleteRental.Text = "Delete Rental";
            this.deleteRental.UseVisualStyleBackColor = true;
            this.deleteRental.Click += new System.EventHandler(this.deleteRental_Click);
            // 
            // edit_rental
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1474, 929);
            this.Controls.Add(this.deleteRental);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Imsotiredoflabels);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label12341342344);
            this.Controls.Add(this.transactionID);
            this.Controls.Add(this.feesPaid);
            this.Controls.Add(this.returnDate);
            this.Controls.Add(this.RbranchID);
            this.Controls.Add(this.RempID);
            this.Controls.Add(this.driverNum);
            this.Controls.Add(this.plateNum);
            this.Controls.Add(this.RTempID);
            this.Controls.Add(this.RTbranchID);
            this.Controls.Add(this.expectedReturn);
            this.Controls.Add(this.checkOutDate);
            this.Controls.Add(this.returnCost);
            this.Controls.Add(this.lateCost);
            this.Controls.Add(this.baseCost);
            this.Name = "edit_rental";
            this.Text = "Edit Rental";
            this.Load += new System.EventHandler(this.edit_rental_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox baseCost;
        private System.Windows.Forms.TextBox lateCost;
        private System.Windows.Forms.TextBox returnCost;
        private System.Windows.Forms.TextBox checkOutDate;
        private System.Windows.Forms.TextBox expectedReturn;
        private System.Windows.Forms.TextBox RTbranchID;
        private System.Windows.Forms.TextBox RTempID;
        private System.Windows.Forms.TextBox plateNum;
        private System.Windows.Forms.TextBox driverNum;
        private System.Windows.Forms.TextBox RempID;
        private System.Windows.Forms.TextBox RbranchID;
        private System.Windows.Forms.TextBox returnDate;
        private System.Windows.Forms.TextBox feesPaid;
        private System.Windows.Forms.Label transactionID;
        private System.Windows.Forms.Label label12341342344;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label Imsotiredoflabels;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Button deleteRental;
    }
}