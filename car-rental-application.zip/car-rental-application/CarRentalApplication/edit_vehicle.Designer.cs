﻿namespace CarRentalApplication
{
    partial class edit_vehicle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.plateNumber = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.kilometersLabel = new System.Windows.Forms.Label();
            this.branch_id = new System.Windows.Forms.TextBox();
            this.type_id = new System.Windows.Forms.TextBox();
            this.condition = new System.Windows.Forms.TextBox();
            this.colour = new System.Windows.Forms.TextBox();
            this.year = new System.Windows.Forms.TextBox();
            this.model = new System.Windows.Forms.TextBox();
            this.make = new System.Windows.Forms.TextBox();
            this.kms = new System.Windows.Forms.TextBox();
            this.Save = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.deleteVehicle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // plateNumber
            // 
            this.plateNumber.AutoSize = true;
            this.plateNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plateNumber.Location = new System.Drawing.Point(579, 70);
            this.plateNumber.Name = "plateNumber";
            this.plateNumber.Size = new System.Drawing.Size(0, 51);
            this.plateNumber.TabIndex = 49;
            this.plateNumber.Click += new System.EventHandler(this.Imsotiredoflabels_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(220, 648);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 51);
            this.label10.TabIndex = 47;
            this.label10.Text = "Type";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(220, 730);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(159, 51);
            this.label8.TabIndex = 46;
            this.label8.Text = "Branch";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(220, 579);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(205, 51);
            this.label7.TabIndex = 45;
            this.label7.Text = "Condition";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(220, 504);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(149, 51);
            this.label6.TabIndex = 44;
            this.label6.Text = "Colour";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(220, 422);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 51);
            this.label5.TabIndex = 43;
            this.label5.Text = "Year";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(220, 340);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 51);
            this.label4.TabIndex = 42;
            this.label4.Text = "Model";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(220, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(276, 51);
            this.label3.TabIndex = 41;
            this.label3.Text = "Manufacturer";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // kilometersLabel
            // 
            this.kilometersLabel.AutoSize = true;
            this.kilometersLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kilometersLabel.Location = new System.Drawing.Point(220, 169);
            this.kilometersLabel.Name = "kilometersLabel";
            this.kilometersLabel.Size = new System.Drawing.Size(227, 51);
            this.kilometersLabel.TabIndex = 40;
            this.kilometersLabel.Text = "Kilometers";
            this.kilometersLabel.Click += new System.EventHandler(this.label12341342344_Click);
            // 
            // branch_id
            // 
            this.branch_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.branch_id.Location = new System.Drawing.Point(588, 722);
            this.branch_id.Name = "branch_id";
            this.branch_id.Size = new System.Drawing.Size(344, 56);
            this.branch_id.TabIndex = 38;
            this.branch_id.TextChanged += new System.EventHandler(this.plateNum_TextChanged);
            // 
            // type_id
            // 
            this.type_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.type_id.Location = new System.Drawing.Point(588, 643);
            this.type_id.Name = "type_id";
            this.type_id.Size = new System.Drawing.Size(344, 56);
            this.type_id.TabIndex = 37;
            this.type_id.TextChanged += new System.EventHandler(this.RTempID_TextChanged);
            // 
            // condition
            // 
            this.condition.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.condition.Location = new System.Drawing.Point(588, 571);
            this.condition.Name = "condition";
            this.condition.Size = new System.Drawing.Size(344, 56);
            this.condition.TabIndex = 36;
            this.condition.TextChanged += new System.EventHandler(this.RTbranchID_TextChanged);
            // 
            // colour
            // 
            this.colour.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colour.Location = new System.Drawing.Point(588, 494);
            this.colour.Name = "colour";
            this.colour.Size = new System.Drawing.Size(344, 56);
            this.colour.TabIndex = 35;
            this.colour.TextChanged += new System.EventHandler(this.expectedReturn_TextChanged);
            // 
            // year
            // 
            this.year.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.year.Location = new System.Drawing.Point(588, 416);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(344, 56);
            this.year.TabIndex = 34;
            this.year.TextChanged += new System.EventHandler(this.checkOutDate_TextChanged);
            // 
            // model
            // 
            this.model.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.model.Location = new System.Drawing.Point(588, 334);
            this.model.Name = "model";
            this.model.Size = new System.Drawing.Size(344, 56);
            this.model.TabIndex = 33;
            this.model.TextChanged += new System.EventHandler(this.returnCost_TextChanged);
            // 
            // make
            // 
            this.make.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.make.Location = new System.Drawing.Point(588, 244);
            this.make.Name = "make";
            this.make.Size = new System.Drawing.Size(344, 56);
            this.make.TabIndex = 32;
            this.make.TextChanged += new System.EventHandler(this.lateCost_TextChanged);
            // 
            // kms
            // 
            this.kms.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kms.Location = new System.Drawing.Point(588, 161);
            this.kms.Name = "kms";
            this.kms.Size = new System.Drawing.Size(344, 56);
            this.kms.TabIndex = 31;
            this.kms.TextChanged += new System.EventHandler(this.baseCost_TextChanged);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(1124, 161);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(253, 361);
            this.Save.TabIndex = 50;
            this.Save.Text = "Save Changes";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(12, 12);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(125, 59);
            this.backButton.TabIndex = 51;
            this.backButton.Text = "< Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // deleteVehicle
            // 
            this.deleteVehicle.Location = new System.Drawing.Point(1124, 722);
            this.deleteVehicle.Name = "deleteVehicle";
            this.deleteVehicle.Size = new System.Drawing.Size(253, 92);
            this.deleteVehicle.TabIndex = 52;
            this.deleteVehicle.Text = "Delete Vehicle";
            this.deleteVehicle.UseVisualStyleBackColor = true;
            this.deleteVehicle.Click += new System.EventHandler(this.deleteVehicle_Click);
            // 
            // edit_vehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1474, 929);
            this.Controls.Add(this.deleteVehicle);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.plateNumber);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.kilometersLabel);
            this.Controls.Add(this.branch_id);
            this.Controls.Add(this.type_id);
            this.Controls.Add(this.condition);
            this.Controls.Add(this.colour);
            this.Controls.Add(this.year);
            this.Controls.Add(this.model);
            this.Controls.Add(this.make);
            this.Controls.Add(this.kms);
            this.Name = "edit_vehicle";
            this.Text = "Edit Vehicle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label plateNumber;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label kilometersLabel;
        private System.Windows.Forms.TextBox branch_id;
        private System.Windows.Forms.TextBox type_id;
        private System.Windows.Forms.TextBox condition;
        private System.Windows.Forms.TextBox colour;
        private System.Windows.Forms.TextBox year;
        private System.Windows.Forms.TextBox model;
        private System.Windows.Forms.TextBox make;
        private System.Windows.Forms.TextBox kms;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Button deleteVehicle;
    }
}