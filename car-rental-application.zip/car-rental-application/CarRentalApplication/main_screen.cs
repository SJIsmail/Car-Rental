﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class main_screen : Form
    {
        public database db;
        public main_screen(database t)
        {
            db = t;
            InitializeComponent();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void viewCustomers_Click(object sender, EventArgs e)
        {
            customer_select select_cus = new customer_select(db);
            this.Hide();
            select_cus.ShowDialog();
            this.Show();
        }

        private void viewExistingReservations_Click(object sender, EventArgs e)
        {
            rental_transactions all_trans = new rental_transactions(db);
            this.Hide();
            all_trans.ShowDialog();
            this.Show();
        }

        private void viewVehicleInventory_Click(object sender, EventArgs e)
        {
            vehicle_inventory vehicles = new vehicle_inventory(db);
            this.Hide();
            vehicles.ShowDialog();
            this.Show(); ;
        }

        private void viewReports_Click(object sender, EventArgs e)
        {
            reports report = new reports(db);
            report.Show();
        }
    }
}
