﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class vehicle_inventory : Form
    {
        public database db;
        DataRow row = null;
        DataRow rowSelect = null;
        DataTable DT = new DataTable();

        string emptyQuery = @"select * from Vehicle where condition > 0 and condition < 6;";
        string vehicleID = null;
        string searchQuery = null;

        public vehicle_inventory(database t)
        {
            db = t;
            InitializeComponent();
            this.Height = 530;
            this.Width = 885;
            this.VehicleTable.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.VehicleTable.MultiSelect = false;

            db.query(emptyQuery); //loading data into vehicle table
            DT.Load(db.myReader);
            VehicleTable.DataSource = DT;
            db.myReader.Close(); //resetting reader


        }

        private void vehicle_inventory_Load(object sender, EventArgs e)
        {

        }

        private void VehicleTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            rowSelect = ((DataRowView)VehicleTable.CurrentRow.DataBoundItem).Row;
            vehicleID = rowSelect["plate_num"].ToString();
        }

        private void modify_vehicle_Click(object sender, EventArgs e)
        {
            if (vehicleID != null)
            {
                row = ((DataRowView)VehicleTable.CurrentRow.DataBoundItem).Row;
                edit_vehicle editVehicle = new edit_vehicle(db, row);
                this.Hide();
                editVehicle.ShowDialog();
                db.query(emptyQuery);
                DT.Clear();
                DT.Load(db.myReader);
                VehicleTable.DataSource = DT;
                db.myReader.Close(); //resetting reader
                this.Show();
            }
            else
            {
                MessageBox.Show("Please Select a Vehicle Before Preceeding");
            }
        }

        private void LoadVehicleTable_Click(object sender, EventArgs e)
        {
            if (branch_id.Text != "")
            {
                try
                {
                    searchQuery = $"select * from Vehicle where branch_id = '{branch_id.Text}' and condition > 0;";
                    db.query(searchQuery);
                    DT.Clear();
                    DT.Load(db.myReader);
                    VehicleTable.DataSource = DT;
                    db.myReader.Close(); //resetting reader
                }
                catch
                {
                    MessageBox.Show("Branch ID Not Found");
                }
            }
            else
            {
                MessageBox.Show("Invalid Search Terms");
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CreateNewVehicle_Click(object sender, EventArgs e)
        {
            new_vehicle newVehicle = new new_vehicle(db);
            this.Hide();
            newVehicle.ShowDialog();
            db.query(emptyQuery); //loading data into vehicle table
            DT.Clear();
            DT.Load(db.myReader);
            VehicleTable.DataSource = DT;
            db.myReader.Close(); //resetting reader
            this.Show();
        }
    }
}
