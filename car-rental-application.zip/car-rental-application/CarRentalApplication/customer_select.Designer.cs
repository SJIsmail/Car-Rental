﻿namespace CarRentalApplication
{
    partial class customer_select
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CustomerTable = new System.Windows.Forms.DataGridView();
            this.LoadCustTable = new System.Windows.Forms.Button();
            this.CustDataType = new System.Windows.Forms.ComboBox();
            this.UserCustSearch = new System.Windows.Forms.TextBox();
            this.CreateNewCustomer = new System.Windows.Forms.Button();
            this.CreateReservation = new System.Windows.Forms.Button();
            this.edit_customer = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerTable)).BeginInit();
            this.SuspendLayout();
            // 
            // CustomerTable
            // 
            this.CustomerTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CustomerTable.Location = new System.Drawing.Point(52, 93);
            this.CustomerTable.Name = "CustomerTable";
            this.CustomerTable.ReadOnly = true;
            this.CustomerTable.RowTemplate.Height = 33;
            this.CustomerTable.Size = new System.Drawing.Size(1604, 716);
            this.CustomerTable.TabIndex = 0;
            this.CustomerTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Customers_CellContentClick);
            // 
            // LoadCustTable
            // 
            this.LoadCustTable.Location = new System.Drawing.Point(1245, 14);
            this.LoadCustTable.Name = "LoadCustTable";
            this.LoadCustTable.Size = new System.Drawing.Size(211, 55);
            this.LoadCustTable.TabIndex = 1;
            this.LoadCustTable.Text = "Search";
            this.LoadCustTable.UseVisualStyleBackColor = true;
            this.LoadCustTable.Click += new System.EventHandler(this.LoadCustTable_Click);
            // 
            // CustDataType
            // 
            this.CustDataType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CustDataType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustDataType.FormattingEnabled = true;
            this.CustDataType.Items.AddRange(new object[] {
            "",
            "First Name",
            "Last Name",
            "Phone Number",
            "Driver\'s Licence Number"});
            this.CustDataType.Location = new System.Drawing.Point(254, 16);
            this.CustDataType.Name = "CustDataType";
            this.CustDataType.Size = new System.Drawing.Size(445, 45);
            this.CustDataType.TabIndex = 2;
            this.CustDataType.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // UserCustSearch
            // 
            this.UserCustSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserCustSearch.Location = new System.Drawing.Point(705, 17);
            this.UserCustSearch.Name = "UserCustSearch";
            this.UserCustSearch.Size = new System.Drawing.Size(534, 44);
            this.UserCustSearch.TabIndex = 3;
            // 
            // CreateNewCustomer
            // 
            this.CreateNewCustomer.Location = new System.Drawing.Point(1284, 843);
            this.CreateNewCustomer.Name = "CreateNewCustomer";
            this.CreateNewCustomer.Size = new System.Drawing.Size(372, 55);
            this.CreateNewCustomer.TabIndex = 4;
            this.CreateNewCustomer.Text = "Create New Customer";
            this.CreateNewCustomer.UseVisualStyleBackColor = true;
            this.CreateNewCustomer.Click += new System.EventHandler(this.CreateNewCustomer_Click);
            // 
            // CreateReservation
            // 
            this.CreateReservation.Location = new System.Drawing.Point(52, 843);
            this.CreateReservation.Name = "CreateReservation";
            this.CreateReservation.Size = new System.Drawing.Size(376, 55);
            this.CreateReservation.TabIndex = 5;
            this.CreateReservation.Text = "Create Reservation";
            this.CreateReservation.UseVisualStyleBackColor = true;
            this.CreateReservation.Click += new System.EventHandler(this.CreateReservation_Click);
            // 
            // edit_customer
            // 
            this.edit_customer.Location = new System.Drawing.Point(725, 843);
            this.edit_customer.Name = "edit_customer";
            this.edit_customer.Size = new System.Drawing.Size(284, 55);
            this.edit_customer.TabIndex = 6;
            this.edit_customer.Text = "Modify Customer Details";
            this.edit_customer.UseVisualStyleBackColor = true;
            this.edit_customer.Click += new System.EventHandler(this.edit_customer_Click);
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(12, 12);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(125, 59);
            this.backButton.TabIndex = 17;
            this.backButton.Text = "< Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click_1);
            // 
            // customer_select
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1744, 929);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.edit_customer);
            this.Controls.Add(this.CreateReservation);
            this.Controls.Add(this.CreateNewCustomer);
            this.Controls.Add(this.UserCustSearch);
            this.Controls.Add(this.CustDataType);
            this.Controls.Add(this.LoadCustTable);
            this.Controls.Add(this.CustomerTable);
            this.Name = "customer_select";
            ((System.ComponentModel.ISupportInitialize)(this.CustomerTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView CustomerTable;
        private System.Windows.Forms.Button LoadCustTable;
        private System.Windows.Forms.ComboBox CustDataType;
        private System.Windows.Forms.TextBox UserCustSearch;
        private System.Windows.Forms.Button CreateNewCustomer;
        private System.Windows.Forms.Button CreateReservation;
        private System.Windows.Forms.Button edit_customer;
        private System.Windows.Forms.Button backButton;
    }
}