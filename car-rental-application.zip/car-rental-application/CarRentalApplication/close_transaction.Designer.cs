﻿namespace CarRentalApplication
{
    partial class close_transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backButton = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Imsotiredoflabels = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label12341342344 = new System.Windows.Forms.Label();
            this.transactionID = new System.Windows.Forms.Label();
            this.feesDue = new System.Windows.Forms.TextBox();
            this.returnDate = new System.Windows.Forms.TextBox();
            this.RbranchID = new System.Windows.Forms.TextBox();
            this.RempID = new System.Windows.Forms.TextBox();
            this.driverNum = new System.Windows.Forms.TextBox();
            this.plateNum = new System.Windows.Forms.TextBox();
            this.RTempID = new System.Windows.Forms.TextBox();
            this.RTbranchID = new System.Windows.Forms.TextBox();
            this.expectedReturn = new System.Windows.Forms.TextBox();
            this.checkOutDate = new System.Windows.Forms.TextBox();
            this.returnCost = new System.Windows.Forms.TextBox();
            this.lateCost = new System.Windows.Forms.TextBox();
            this.baseCost = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.retrunFeeBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.returnCondition = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(22, 30);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(125, 59);
            this.backButton.TabIndex = 64;
            this.backButton.Text = "< Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(905, 718);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(513, 180);
            this.Save.TabIndex = 63;
            this.Save.Text = "Close Reservation";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1065, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(388, 51);
            this.label1.TabIndex = 62;
            this.label1.Text = "Return Transaction";
            // 
            // Imsotiredoflabels
            // 
            this.Imsotiredoflabels.AutoSize = true;
            this.Imsotiredoflabels.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Imsotiredoflabels.Location = new System.Drawing.Point(381, 113);
            this.Imsotiredoflabels.Name = "Imsotiredoflabels";
            this.Imsotiredoflabels.Size = new System.Drawing.Size(384, 51);
            this.Imsotiredoflabels.TabIndex = 61;
            this.Imsotiredoflabels.Text = "Rental Transaction";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(799, 537);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(213, 51);
            this.label14.TabIndex = 60;
            this.label14.Text = "Late Fees";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(799, 380);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(253, 51);
            this.label13.TabIndex = 59;
            this.label13.Text = "Return Date";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(799, 290);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(213, 51);
            this.label12.TabIndex = 58;
            this.label12.Text = "Branch ID";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(22, 847);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(301, 51);
            this.label11.TabIndex = 57;
            this.label11.Text = "Driver Number";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(22, 691);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(269, 51);
            this.label10.TabIndex = 56;
            this.label10.Text = "Employee ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(799, 207);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(269, 51);
            this.label9.TabIndex = 55;
            this.label9.Text = "Employee ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 773);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(285, 51);
            this.label8.TabIndex = 54;
            this.label8.Text = "Plate Number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(22, 622);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(213, 51);
            this.label7.TabIndex = 53;
            this.label7.Text = "Branch ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(22, 547);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(343, 51);
            this.label6.TabIndex = 52;
            this.label6.Text = "Expected Return";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(22, 465);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(327, 51);
            this.label5.TabIndex = 51;
            this.label5.Text = "Check Out Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 383);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(251, 51);
            this.label4.TabIndex = 50;
            this.label4.Text = "Return Cost";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 51);
            this.label3.TabIndex = 49;
            this.label3.Text = "Late Cost";
            // 
            // label12341342344
            // 
            this.label12341342344.AutoSize = true;
            this.label12341342344.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12341342344.Location = new System.Drawing.Point(22, 212);
            this.label12341342344.Name = "label12341342344";
            this.label12341342344.Size = new System.Drawing.Size(221, 51);
            this.label12341342344.TabIndex = 48;
            this.label12341342344.Text = "Base Cost";
            // 
            // transactionID
            // 
            this.transactionID.AutoSize = true;
            this.transactionID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transactionID.Location = new System.Drawing.Point(734, 45);
            this.transactionID.Name = "transactionID";
            this.transactionID.Size = new System.Drawing.Size(0, 51);
            this.transactionID.TabIndex = 47;
            // 
            // feesDue
            // 
            this.feesDue.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feesDue.Location = new System.Drawing.Point(1084, 537);
            this.feesDue.Name = "feesDue";
            this.feesDue.ReadOnly = true;
            this.feesDue.Size = new System.Drawing.Size(344, 56);
            this.feesDue.TabIndex = 46;
            // 
            // returnDate
            // 
            this.returnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnDate.Location = new System.Drawing.Point(1084, 380);
            this.returnDate.Name = "returnDate";
            this.returnDate.Size = new System.Drawing.Size(344, 56);
            this.returnDate.TabIndex = 45;
            this.returnDate.TextChanged += new System.EventHandler(this.returnDate_TextChanged);
            // 
            // RbranchID
            // 
            this.RbranchID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbranchID.Location = new System.Drawing.Point(1084, 290);
            this.RbranchID.Name = "RbranchID";
            this.RbranchID.Size = new System.Drawing.Size(344, 56);
            this.RbranchID.TabIndex = 44;
            this.RbranchID.TextChanged += new System.EventHandler(this.RbranchID_TextChanged);
            // 
            // RempID
            // 
            this.RempID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RempID.Location = new System.Drawing.Point(1084, 207);
            this.RempID.Name = "RempID";
            this.RempID.Size = new System.Drawing.Size(344, 56);
            this.RempID.TabIndex = 43;
            // 
            // driverNum
            // 
            this.driverNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.driverNum.Location = new System.Drawing.Point(390, 842);
            this.driverNum.Name = "driverNum";
            this.driverNum.ReadOnly = true;
            this.driverNum.Size = new System.Drawing.Size(344, 56);
            this.driverNum.TabIndex = 42;
            // 
            // plateNum
            // 
            this.plateNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plateNum.Location = new System.Drawing.Point(390, 765);
            this.plateNum.Name = "plateNum";
            this.plateNum.ReadOnly = true;
            this.plateNum.Size = new System.Drawing.Size(344, 56);
            this.plateNum.TabIndex = 41;
            // 
            // RTempID
            // 
            this.RTempID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RTempID.Location = new System.Drawing.Point(390, 686);
            this.RTempID.Name = "RTempID";
            this.RTempID.ReadOnly = true;
            this.RTempID.Size = new System.Drawing.Size(344, 56);
            this.RTempID.TabIndex = 40;
            // 
            // RTbranchID
            // 
            this.RTbranchID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RTbranchID.Location = new System.Drawing.Point(390, 614);
            this.RTbranchID.Name = "RTbranchID";
            this.RTbranchID.ReadOnly = true;
            this.RTbranchID.Size = new System.Drawing.Size(344, 56);
            this.RTbranchID.TabIndex = 39;
            // 
            // expectedReturn
            // 
            this.expectedReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expectedReturn.Location = new System.Drawing.Point(390, 537);
            this.expectedReturn.Name = "expectedReturn";
            this.expectedReturn.ReadOnly = true;
            this.expectedReturn.Size = new System.Drawing.Size(344, 56);
            this.expectedReturn.TabIndex = 38;
            // 
            // checkOutDate
            // 
            this.checkOutDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOutDate.Location = new System.Drawing.Point(390, 459);
            this.checkOutDate.Name = "checkOutDate";
            this.checkOutDate.ReadOnly = true;
            this.checkOutDate.Size = new System.Drawing.Size(344, 56);
            this.checkOutDate.TabIndex = 37;
            // 
            // returnCost
            // 
            this.returnCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnCost.Location = new System.Drawing.Point(390, 377);
            this.returnCost.Name = "returnCost";
            this.returnCost.ReadOnly = true;
            this.returnCost.Size = new System.Drawing.Size(344, 56);
            this.returnCost.TabIndex = 36;
            // 
            // lateCost
            // 
            this.lateCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lateCost.Location = new System.Drawing.Point(390, 287);
            this.lateCost.Name = "lateCost";
            this.lateCost.ReadOnly = true;
            this.lateCost.Size = new System.Drawing.Size(344, 56);
            this.lateCost.TabIndex = 35;
            // 
            // baseCost
            // 
            this.baseCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.baseCost.Location = new System.Drawing.Point(390, 204);
            this.baseCost.Name = "baseCost";
            this.baseCost.ReadOnly = true;
            this.baseCost.Size = new System.Drawing.Size(344, 56);
            this.baseCost.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(799, 622);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(258, 51);
            this.label2.TabIndex = 66;
            this.label2.Text = "Return Fees";
            // 
            // retrunFeeBox
            // 
            this.retrunFeeBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.retrunFeeBox.Location = new System.Drawing.Point(1084, 622);
            this.retrunFeeBox.Name = "retrunFeeBox";
            this.retrunFeeBox.ReadOnly = true;
            this.retrunFeeBox.Size = new System.Drawing.Size(344, 56);
            this.retrunFeeBox.TabIndex = 65;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(799, 465);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(205, 51);
            this.label15.TabIndex = 67;
            this.label15.Text = "Conidtion";
            // 
            // returnCondition
            // 
            this.returnCondition.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnCondition.Location = new System.Drawing.Point(1084, 459);
            this.returnCondition.Name = "returnCondition";
            this.returnCondition.Size = new System.Drawing.Size(344, 56);
            this.returnCondition.TabIndex = 68;
            // 
            // close_transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1474, 929);
            this.Controls.Add(this.returnCondition);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.retrunFeeBox);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Imsotiredoflabels);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label12341342344);
            this.Controls.Add(this.transactionID);
            this.Controls.Add(this.feesDue);
            this.Controls.Add(this.returnDate);
            this.Controls.Add(this.RbranchID);
            this.Controls.Add(this.RempID);
            this.Controls.Add(this.driverNum);
            this.Controls.Add(this.plateNum);
            this.Controls.Add(this.RTempID);
            this.Controls.Add(this.RTbranchID);
            this.Controls.Add(this.expectedReturn);
            this.Controls.Add(this.checkOutDate);
            this.Controls.Add(this.returnCost);
            this.Controls.Add(this.lateCost);
            this.Controls.Add(this.baseCost);
            this.Name = "close_transaction";
            this.Text = "Close Reservation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Imsotiredoflabels;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label12341342344;
        private System.Windows.Forms.Label transactionID;
        private System.Windows.Forms.TextBox feesDue;
        private System.Windows.Forms.TextBox returnDate;
        private System.Windows.Forms.TextBox RbranchID;
        private System.Windows.Forms.TextBox RempID;
        private System.Windows.Forms.TextBox driverNum;
        private System.Windows.Forms.TextBox plateNum;
        private System.Windows.Forms.TextBox RTempID;
        private System.Windows.Forms.TextBox RTbranchID;
        private System.Windows.Forms.TextBox expectedReturn;
        private System.Windows.Forms.TextBox checkOutDate;
        private System.Windows.Forms.TextBox returnCost;
        private System.Windows.Forms.TextBox lateCost;
        private System.Windows.Forms.TextBox baseCost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox retrunFeeBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox returnCondition;
    }
}