﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public class database
    {
        public SqlConnection myConnection;
        public SqlCommand myCommand;
        public SqlDataReader myReader;

        public database(string username, string password)
        {
            /* Starting the connection */
            SqlConnection myConnection = new SqlConnection(
                    "user id=" + username + ";" + // Username
                    "password=" + password + ";" + // Password
                    "server=localhost;" + // IP for the server
                    "database=CarRentalDatabase; " + // Database to connect to
                    "connection timeout=30"); // Timeout in seconds
            myConnection.Open(); // Open connection
            myCommand = new SqlCommand();
            myCommand.Connection = myConnection; // Link the command stream to the connection
        }
        public void insert(string command)
        {

            myCommand.CommandText = command;
            //MessageBox.Show(myCommand.CommandText);
            myCommand.ExecuteNonQuery();
        }
        //
        public void query(string command)
        {

            myCommand.CommandText = command;
            //MessageBox.Show(myCommand.CommandText);
            myReader = myCommand.ExecuteReader();
        }
        public SqlDataReader read(string command)
        {

            myCommand.CommandText = command;
            //MessageBox.Show(myCommand.CommandText);
            return myCommand.ExecuteReader();
        }
    }
}
