﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class edit_customer : Form
    {
        public database db;
        DataRow row;
        string old_license;
        public edit_customer(database t, DataRow row_in)
        {
            InitializeComponent();
            db = t;
            row = row_in;
            old_license = row["driver_num"].ToString();
            license_no.Text = row["driver_num"].ToString();
            f_name.Text = row["f_name"].ToString();
            l_name.Text = row["l_name"].ToString();
            building_num.Text = row["building_num"].ToString();
            street_name.Text = row["street_name"].ToString();
            street_type.Text = row["street_type"].ToString();
            city.Text = row["city"].ToString();
            province.Text = row["province"].ToString();
            post_code.Text = row["post_code"].ToString();
            phone_num.Text = row["phone_num"].ToString();


        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cust_submit_Click(object sender, EventArgs e)
        {
            try
            { 
                string today = DateTime.Today.ToString("yyyy-MM-dd");
                string command = @"Update Customer set driver_num='"+license_no.Text.ToUpper() + "', f_name='" + f_name.Text.ToUpper() + "', l_name='" + l_name.Text.ToUpper() +
                    "', building_num='" + building_num.Text.ToUpper() + "', street_name='" + street_name.Text.ToUpper() + "', street_type='" + street_type.Text.ToUpper() +
                    "', city='" + city.Text.ToUpper() + "', province='" + province.Text.ToUpper() + "', post_code='" + post_code.Text.ToUpper() + "', phone_num='" + phone_num.Text +
                    "' where driver_num='" + old_license + "'";
                db.insert(command);
                MessageBox.Show("Customer Information Successfully Updated"); //record updated
                this.Close(); //exit window
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.ToString(), "Input appears to be in incorrect format, review and try again. ");
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void license_no_TextChanged(object sender, EventArgs e)
        {
        }

        private void edit_customer_Load(object sender, EventArgs e)
        {
        }
    }
}
