﻿namespace CarRentalApplication
{
    partial class create_reservation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.VehicleTable = new System.Windows.Forms.DataGridView();
            this.SearchVehicles = new System.Windows.Forms.Button();
            this.EmployeeID = new System.Windows.Forms.TextBox();
            this.Finalize = new System.Windows.Forms.Button();
            this.YYYY = new System.Windows.Forms.TextBox();
            this.returndate = new System.Windows.Forms.Label();
            this.MM = new System.Windows.Forms.TextBox();
            this.DD = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.VehicleTable)).BeginInit();
            this.SuspendLayout();
            // 
            // VehicleTable
            // 
            this.VehicleTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VehicleTable.Location = new System.Drawing.Point(12, 267);
            this.VehicleTable.Name = "VehicleTable";
            this.VehicleTable.ReadOnly = true;
            this.VehicleTable.RowTemplate.Height = 33;
            this.VehicleTable.Size = new System.Drawing.Size(1624, 654);
            this.VehicleTable.TabIndex = 0;
            this.VehicleTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.VehicleTable_CellContentClick);
            // 
            // SearchVehicles
            // 
            this.SearchVehicles.Location = new System.Drawing.Point(288, 13);
            this.SearchVehicles.Name = "SearchVehicles";
            this.SearchVehicles.Size = new System.Drawing.Size(1107, 49);
            this.SearchVehicles.TabIndex = 1;
            this.SearchVehicles.Text = "Search Inventory";
            this.SearchVehicles.UseVisualStyleBackColor = true;
            this.SearchVehicles.Click += new System.EventHandler(this.SearchVehicles_Click);
            // 
            // EmployeeID
            // 
            this.EmployeeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeID.Location = new System.Drawing.Point(13, 13);
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.Size = new System.Drawing.Size(250, 49);
            this.EmployeeID.TabIndex = 2;
            this.EmployeeID.Text = "Employee ID";
            // 
            // Finalize
            // 
            this.Finalize.Location = new System.Drawing.Point(1418, 13);
            this.Finalize.Name = "Finalize";
            this.Finalize.Size = new System.Drawing.Size(218, 228);
            this.Finalize.TabIndex = 3;
            this.Finalize.Text = "Finalize";
            this.Finalize.UseVisualStyleBackColor = true;
            this.Finalize.Click += new System.EventHandler(this.Finalize_Click);
            // 
            // YYYY
            // 
            this.YYYY.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YYYY.Location = new System.Drawing.Point(520, 104);
            this.YYYY.Name = "YYYY";
            this.YYYY.Size = new System.Drawing.Size(144, 56);
            this.YYYY.TabIndex = 4;
            this.YYYY.Text = "YYYY";
            // 
            // returndate
            // 
            this.returndate.AutoSize = true;
            this.returndate.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returndate.Location = new System.Drawing.Point(12, 107);
            this.returndate.Name = "returndate";
            this.returndate.Size = new System.Drawing.Size(504, 51);
            this.returndate.TabIndex = 5;
            this.returndate.Text = "Expected Date of Return:";
            // 
            // MM
            // 
            this.MM.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MM.Location = new System.Drawing.Point(688, 104);
            this.MM.Name = "MM";
            this.MM.Size = new System.Drawing.Size(100, 56);
            this.MM.TabIndex = 6;
            this.MM.Text = "MM";
            // 
            // DD
            // 
            this.DD.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DD.Location = new System.Drawing.Point(816, 104);
            this.DD.Name = "DD";
            this.DD.Size = new System.Drawing.Size(100, 56);
            this.DD.TabIndex = 7;
            this.DD.Text = "DD";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(584, 51);
            this.label1.TabIndex = 8;
            this.label1.Text = "Select a Vehicle From Below:";
            // 
            // create_reservation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1648, 933);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DD);
            this.Controls.Add(this.MM);
            this.Controls.Add(this.returndate);
            this.Controls.Add(this.YYYY);
            this.Controls.Add(this.Finalize);
            this.Controls.Add(this.EmployeeID);
            this.Controls.Add(this.SearchVehicles);
            this.Controls.Add(this.VehicleTable);
            this.Name = "create_reservation";
            this.Text = "Create Reservation";
            ((System.ComponentModel.ISupportInitialize)(this.VehicleTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView VehicleTable;
        private System.Windows.Forms.Button SearchVehicles;
        private System.Windows.Forms.TextBox EmployeeID;
        private System.Windows.Forms.Button Finalize;
        private System.Windows.Forms.TextBox YYYY;
        private System.Windows.Forms.Label returndate;
        private System.Windows.Forms.TextBox MM;
        private System.Windows.Forms.TextBox DD;
        private System.Windows.Forms.Label label1;
    }
}