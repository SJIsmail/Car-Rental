﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class edit_rental : Form
    {
        public database db;
        DataRow row = null;
        public edit_rental(database t, DataRow rowSelect)
        {
            row = rowSelect;
            db = t;
            InitializeComponent();
            this.Height = 530;
            this.Width = 885;
            //setting all text boxes to original values pulled from previous form
            transactionID.Text = row["transaction_id"].ToString();
            baseCost.Text = String.Format("{0:0.00}", Convert.ToDouble(row["base_cost"]));
            lateCost.Text = String.Format("{0:0.00}", Convert.ToDouble(row["late_cost"]));
            returnCost.Text = String.Format("{0:0.00}", Convert.ToDouble(row["return_cost"]));
            checkOutDate.Text = ((DateTime)row["check_out_date"]).ToString("yyyy-MM-dd");
            expectedReturn.Text = ((DateTime)row["expected_return"]).ToString("yyyy-MM-dd");
            RTbranchID.Text = row["rental_branch"].ToString();
            RTempID.Text = row["created_by"].ToString();
            plateNum.Text = row["plate_num"].ToString();
            driverNum.Text = row["driver_num"].ToString();
            if (row["returned_by"].ToString() != "")
            {
                RempID.Text = row["returned_by"].ToString();
                RbranchID.Text = row["return_branch"].ToString();
                returnDate.Text = ((DateTime)row["return_date"]).ToString("yyyy-MM-dd");
                feesPaid.Text = String.Format("{0:0.00}", Convert.ToDouble(row["fees_paid"]));
            }
            else
            {
                RempID.ReadOnly = true;
                RbranchID.ReadOnly = true;
                returnDate.ReadOnly = true;
                feesPaid.ReadOnly = true;
            }

        }

        private void edit_rental_Load(object sender, EventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                string command = @"Update Rental_Transaction set base_cost=" + baseCost.Text + ", late_cost=" + lateCost.Text +
                    ", return_cost=" + returnCost.Text + ", check_out_date=TRY_CONVERT(DATE, '" + checkOutDate.Text + "'), expected_return=TRY_CONVERT(DATE, '" + expectedReturn.Text +
                    "'), branch_id='" + RTbranchID.Text + "', emp_id='" + RTempID.Text + "', plate_num='" + plateNum.Text + "', driver_num='" + driverNum.Text +
                    "' where transaction_id='" + transactionID.Text + "'";
                db.insert(command);
                if (row["returned_by"].ToString() != "")
                {
                    try
                    {
                        string commandReturn = @"Update [Returns] set branch_id='" + RbranchID.Text + "', emp_id='" + RempID.Text +
                        "', return_date=TRY_CONVERT(DATE, '" + returnDate.Text + "'), fees_paid=" + feesPaid.Text +
                        " where transaction_id='" + transactionID.Text + "'";
                        db.insert(commandReturn);
                    }
                    catch
                    {
                        MessageBox.Show("Invalid Return Transaction Information");
                    }
                }
                MessageBox.Show("Rental Transaction Successfully Updated"); //record updated
                this.Close(); //exit window
            }
            catch
            {
                MessageBox.Show("Invalid Rental Transaction Information");
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deleteRental_Click(object sender, EventArgs e)
        {
            if (row["returned_by"].ToString() == "")
            {
                try
                {
                    string commandReturn = @"delete from Rental_Transaction where transaction_id='" + transactionID.Text + "'";
                    db.insert(commandReturn);
                }
                catch
                {
                    MessageBox.Show("Return Transaction Deletion Failed");
                }
                MessageBox.Show("Rental Transaction Successfully Deleted"); //record updated
                this.Close(); //exit window
            }
            else
            {
                MessageBox.Show("Return Transactions That Have a Return Associated With Them Are Not Eligible For Deletion");
            }
        }
    }
}
