﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace CarRentalApplication
{
    public partial class new_vehicle : Form
    {
        public database db;
        string command = null;

        public new_vehicle(database t)
        {
            db = t;
            InitializeComponent();
        }
        vehicle_inventory obj = (vehicle_inventory)Application.OpenForms["vehicle_select"];

        private void add_vehicle_btn_Click(object sender, EventArgs e)
        {
            try
            {
                command = @"insert into Vehicle values ('" + platenum_tb.Text +
                    "'," + km_tb.Text +
                    ",'" + make_tb.Text.ToUpper() +
                    "','" + model_tb.Text.ToUpper() +
                    "'," + year_cb.Text +
                    ",'" + colour_tb.Text.ToUpper() +
                    "'," + condition_cb.Text +
                    ",'" + type_cb.SelectedItem.ToString().ToUpper() +
                    "','" + branchid_cb.Text +
                    "')";
            }
            catch
            {
                MessageBox.Show("STRING TING");
            }

            try
            {
                db.insert(command);
                MessageBox.Show("Vehicle Successfully Added to Inventory");
                this.Close();
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.ToString(), "Error");
            }

        }

        private void new_vehicle_Load(object sender, EventArgs e)
        {
            //loading branch ids into combo box
            SqlDataReader dr = db.read("SELECT DISTINCT branch_id from Branch");
            while (dr.Read())
            {
                branchid_cb.Items.Add(dr["branch_id"]);
            }
            dr.Close();

            //loading car types into combo box
            dr = db.read("SELECT [type_id] from Vehicle_Type");
            while (dr.Read())
            {
                type_cb.Items.Add(dr["type_id"]);
            }
            dr.Close();

            //populating years for the combobox
            for (int i = 1950; i <= 2019; i++)
            {
                year_cb.Items.Add(i);
            }

            //condition can only be 1 - 5 
            for (int i = 1; i <= 5; i++)
            {
                condition_cb.Items.Add(i);
            }

            //type_cb.Items.Add("FULLSIZE"); //these ended up being added in a while loop above
            //type_cb.Items.Add("COMPACT");
            //type_cb.Items.Add("MIDSIZE");
        }

        private void back_button_vehicle_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
