﻿namespace CarRentalApplication
{
    partial class main_screen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exit = new System.Windows.Forms.Button();
            this.viewCustomers = new System.Windows.Forms.Button();
            this.viewExistingReservations = new System.Windows.Forms.Button();
            this.viewVehicleInventory = new System.Windows.Forms.Button();
            this.viewReports = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.Location = new System.Drawing.Point(60, 736);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(1096, 73);
            this.exit.TabIndex = 3;
            this.exit.Text = "Quit";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // viewCustomers
            // 
            this.viewCustomers.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewCustomers.Location = new System.Drawing.Point(60, 58);
            this.viewCustomers.Name = "viewCustomers";
            this.viewCustomers.Size = new System.Drawing.Size(498, 219);
            this.viewCustomers.TabIndex = 4;
            this.viewCustomers.Text = "View Customers";
            this.viewCustomers.UseVisualStyleBackColor = true;
            this.viewCustomers.Click += new System.EventHandler(this.viewCustomers_Click);
            // 
            // viewExistingReservations
            // 
            this.viewExistingReservations.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewExistingReservations.Location = new System.Drawing.Point(658, 58);
            this.viewExistingReservations.Name = "viewExistingReservations";
            this.viewExistingReservations.Size = new System.Drawing.Size(498, 219);
            this.viewExistingReservations.TabIndex = 5;
            this.viewExistingReservations.Text = "View Existing Reservations";
            this.viewExistingReservations.UseVisualStyleBackColor = true;
            this.viewExistingReservations.Click += new System.EventHandler(this.viewExistingReservations_Click);
            // 
            // viewVehicleInventory
            // 
            this.viewVehicleInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewVehicleInventory.Location = new System.Drawing.Point(60, 402);
            this.viewVehicleInventory.Name = "viewVehicleInventory";
            this.viewVehicleInventory.Size = new System.Drawing.Size(498, 219);
            this.viewVehicleInventory.TabIndex = 6;
            this.viewVehicleInventory.Text = "View Vehicle Inventory";
            this.viewVehicleInventory.UseVisualStyleBackColor = true;
            this.viewVehicleInventory.Click += new System.EventHandler(this.viewVehicleInventory_Click);
            // 
            // viewReports
            // 
            this.viewReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewReports.Location = new System.Drawing.Point(658, 402);
            this.viewReports.Name = "viewReports";
            this.viewReports.Size = new System.Drawing.Size(498, 219);
            this.viewReports.TabIndex = 7;
            this.viewReports.Text = "View Reports";
            this.viewReports.UseVisualStyleBackColor = true;
            this.viewReports.Click += new System.EventHandler(this.viewReports_Click);
            // 
            // main_screen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1214, 821);
            this.Controls.Add(this.viewReports);
            this.Controls.Add(this.viewVehicleInventory);
            this.Controls.Add(this.viewExistingReservations);
            this.Controls.Add(this.viewCustomers);
            this.Controls.Add(this.exit);
            this.Name = "main_screen";
            this.Text = "Main";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button viewCustomers;
        private System.Windows.Forms.Button viewExistingReservations;
        private System.Windows.Forms.Button viewVehicleInventory;
        private System.Windows.Forms.Button viewReports;
    }
}