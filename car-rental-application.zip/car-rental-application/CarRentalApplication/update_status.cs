﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    // this class should have a method that is passed the driver_num to it from the database,
    // and uses that to query. The return of the query is the number of transactions that customer has.
    // if the number is 3, their status should be updated from Bronze to Gold.
    public class update_status
    {
        string customer; // this should be passed into the method
        public database db;
        public void update(database t, string c)
        {
            db = t;
            customer = c;
      
            // function needs to be passed customer driver num. This is not done. 
            // Uses licence number to check how many closed transactions the customer has
            // if 3, updates the customer to gold. 
            // This NEEDS to be run at the end of closing a reservation
            string command = @"select count(R.transaction_id) as temp from [Returns] R 
                join Rental_Transaction T on R.transaction_id=T.transaction_id where T.driver_num='" + customer +"'";

            db.query(command);
            db.myReader.Read();
            int result = int.Parse(db.myReader["temp"].ToString());
                // result will be a table with a single value, this saves it to an int.
            db.myReader.Close();

            string command2 = $"Update Customer set status_id='GOLD', membership_date= TRY_CONVERT(DATE,'{(DateTime.Today).ToString("yyyy-MM-dd")}') where driver_num='" + customer + "'";
                if (result==3) try {
                db.insert(command2);
                    // this update command should give the customer gold status
                    MessageBox.Show($"Customer with licence number: {customer} has earned GOLD status");
                }
                catch
                {
                    MessageBox.Show("Couldn't update customer membership; something went wrong.");
                }
            // Somewhere here there should be a prompt on screen that tells the user the customer is Gold.
            return;
        }
     } // opens database connection? not sure No Initialize.

}
