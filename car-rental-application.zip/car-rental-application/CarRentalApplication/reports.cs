﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class reports : Form
    {
        public database db;
        //DataRow row = null;
        DataTable DT = new DataTable();

        public reports(database t)
        {
            db = t;
            InitializeComponent();
            this.Height = 523;
            this.Width = 887;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void reportTable1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //rowSelect = ((DataRowView)reportTable1.CurrentRow.DataBoundItem).Row;
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

            }

        private void reportTable2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ReportButton1_Click(object sender, EventArgs e)
        {
            string goldornot=""; //set empty string. Used if user selects bronze AND gold
            if (level_select.Text == "Gold")
            {

                goldornot = ", status_id having status_id='GOLD'"; 
                //appends qualifier to select statement; includes second groupby by part
            }
            if (level_select.Text == "Bronze")
            {

                goldornot = ", status_id having status_id='BRONZE'";
                //appends qualifier to select statement; includes second groupby by part
            }

            string reportquery1 = @"select SUBSTRING(post_code,1,3) as [Postal Code], 
                            count(SUBSTRING(post_code,1,3)) as [# of customers] 
                            from Customer group by SUBSTRING(post_code,1,3)"+goldornot; 

            
            try
            {
            db.query(reportquery1);
            DT.Clear(); // gotta clear the table each time
            DT.Load(db.myReader);
            reportTable1.DataSource = DT;
            db.myReader.Close(); //resetting reader
            }
            catch
            {
                MessageBox.Show("Something went wrong, try again?");
            }
        }

        private void level_select_SelectedIndexChanged(object sender, EventArgs e)
        {
            DT.Clear(); // as soon as you make a selector changes, the table clears
            // can reduce cconfusion; like if the user changes status type but doens't click "go"
        }
    }
}
