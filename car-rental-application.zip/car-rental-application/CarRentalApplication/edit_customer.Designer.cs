﻿namespace CarRentalApplication
{
    partial class edit_customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.back_button = new System.Windows.Forms.Button();
            this.f_name_label = new System.Windows.Forms.Label();
            this.post_code_label = new System.Windows.Forms.Label();
            this.city_label = new System.Windows.Forms.Label();
            this.street_name_label = new System.Windows.Forms.Label();
            this.building_num_label = new System.Windows.Forms.Label();
            this.l_name_label = new System.Windows.Forms.Label();
            this.licence_no_label = new System.Windows.Forms.Label();
            this.f_name = new System.Windows.Forms.TextBox();
            this.l_name = new System.Windows.Forms.TextBox();
            this.license_no = new System.Windows.Forms.TextBox();
            this.building_num = new System.Windows.Forms.TextBox();
            this.street_name = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.street_type = new System.Windows.Forms.ComboBox();
            this.city = new System.Windows.Forms.TextBox();
            this.post_code = new System.Windows.Forms.TextBox();
            this.cust_submit = new System.Windows.Forms.Button();
            this.province = new System.Windows.Forms.ComboBox();
            this.phone_num_label = new System.Windows.Forms.Label();
            this.phone_num = new System.Windows.Forms.TextBox();
            this.province_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // back_button
            // 
            this.back_button.Location = new System.Drawing.Point(12, 12);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(119, 55);
            this.back_button.TabIndex = 11;
            this.back_button.Text = "< Back";
            this.back_button.UseVisualStyleBackColor = true;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // f_name_label
            // 
            this.f_name_label.AutoSize = true;
            this.f_name_label.Location = new System.Drawing.Point(77, 206);
            this.f_name_label.Name = "f_name_label";
            this.f_name_label.Size = new System.Drawing.Size(116, 25);
            this.f_name_label.TabIndex = 1;
            this.f_name_label.Text = "First Name";
            // 
            // post_code_label
            // 
            this.post_code_label.AutoSize = true;
            this.post_code_label.Location = new System.Drawing.Point(77, 419);
            this.post_code_label.Name = "post_code_label";
            this.post_code_label.Size = new System.Drawing.Size(129, 25);
            this.post_code_label.TabIndex = 2;
            this.post_code_label.Text = "Postal Code";
            // 
            // city_label
            // 
            this.city_label.AutoSize = true;
            this.city_label.Location = new System.Drawing.Point(77, 343);
            this.city_label.Name = "city_label";
            this.city_label.Size = new System.Drawing.Size(49, 25);
            this.city_label.TabIndex = 3;
            this.city_label.Text = "City";
            // 
            // street_name_label
            // 
            this.street_name_label.AutoSize = true;
            this.street_name_label.Location = new System.Drawing.Point(552, 267);
            this.street_name_label.Name = "street_name_label";
            this.street_name_label.Size = new System.Drawing.Size(131, 25);
            this.street_name_label.TabIndex = 4;
            this.street_name_label.Text = "Street Name";
            // 
            // building_num_label
            // 
            this.building_num_label.AutoSize = true;
            this.building_num_label.Location = new System.Drawing.Point(77, 273);
            this.building_num_label.Name = "building_num_label";
            this.building_num_label.Size = new System.Drawing.Size(139, 25);
            this.building_num_label.TabIndex = 5;
            this.building_num_label.Text = "Building Num";
            // 
            // l_name_label
            // 
            this.l_name_label.AutoSize = true;
            this.l_name_label.Location = new System.Drawing.Point(552, 203);
            this.l_name_label.Name = "l_name_label";
            this.l_name_label.Size = new System.Drawing.Size(115, 25);
            this.l_name_label.TabIndex = 6;
            this.l_name_label.Text = "Last Name";
            this.l_name_label.Click += new System.EventHandler(this.label6_Click);
            // 
            // licence_no_label
            // 
            this.licence_no_label.AutoSize = true;
            this.licence_no_label.Location = new System.Drawing.Point(77, 139);
            this.licence_no_label.Name = "licence_no_label";
            this.licence_no_label.Size = new System.Drawing.Size(246, 25);
            this.licence_no_label.TabIndex = 7;
            this.licence_no_label.Text = "Driver\'s Licence Number";
            // 
            // f_name
            // 
            this.f_name.Location = new System.Drawing.Point(233, 200);
            this.f_name.Name = "f_name";
            this.f_name.Size = new System.Drawing.Size(298, 31);
            this.f_name.TabIndex = 1;
            // 
            // l_name
            // 
            this.l_name.Location = new System.Drawing.Point(689, 197);
            this.l_name.Name = "l_name";
            this.l_name.Size = new System.Drawing.Size(332, 31);
            this.l_name.TabIndex = 2;
            // 
            // license_no
            // 
            this.license_no.Location = new System.Drawing.Point(339, 133);
            this.license_no.Name = "license_no";
            this.license_no.Size = new System.Drawing.Size(386, 31);
            this.license_no.TabIndex = 0;
            this.license_no.TextChanged += new System.EventHandler(this.license_no_TextChanged);
            // 
            // building_num
            // 
            this.building_num.Location = new System.Drawing.Point(233, 267);
            this.building_num.Name = "building_num";
            this.building_num.Size = new System.Drawing.Size(298, 31);
            this.building_num.TabIndex = 3;
            // 
            // street_name
            // 
            this.street_name.Location = new System.Drawing.Point(689, 264);
            this.street_name.Name = "street_name";
            this.street_name.Size = new System.Drawing.Size(332, 31);
            this.street_name.TabIndex = 4;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // street_type
            // 
            this.street_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.street_type.FormattingEnabled = true;
            this.street_type.Items.AddRange(new object[] {
            "Avenue",
            "Boulevard",
            "Close",
            "Crescent",
            "Lane",
            "Road",
            "Street",
            "Terrace",
            "Way"});
            this.street_type.Location = new System.Drawing.Point(1038, 262);
            this.street_type.Name = "street_type";
            this.street_type.Size = new System.Drawing.Size(121, 33);
            this.street_type.TabIndex = 5;
            // 
            // city
            // 
            this.city.Location = new System.Drawing.Point(233, 340);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(298, 31);
            this.city.TabIndex = 6;
            // 
            // post_code
            // 
            this.post_code.Location = new System.Drawing.Point(233, 413);
            this.post_code.Name = "post_code";
            this.post_code.Size = new System.Drawing.Size(298, 31);
            this.post_code.TabIndex = 8;
            // 
            // cust_submit
            // 
            this.cust_submit.Location = new System.Drawing.Point(501, 536);
            this.cust_submit.Name = "cust_submit";
            this.cust_submit.Size = new System.Drawing.Size(257, 85);
            this.cust_submit.TabIndex = 10;
            this.cust_submit.Text = "Update Profile";
            this.cust_submit.UseVisualStyleBackColor = true;
            this.cust_submit.Click += new System.EventHandler(this.cust_submit_Click);
            // 
            // province
            // 
            this.province.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.province.FormattingEnabled = true;
            this.province.Items.AddRange(new object[] {
            "AB",
            "BC",
            "MN",
            "NB",
            "NL",
            "NW",
            "NV",
            "ON",
            "PE",
            "QC",
            "SK",
            "YK"});
            this.province.Location = new System.Drawing.Point(689, 340);
            this.province.Name = "province";
            this.province.Size = new System.Drawing.Size(332, 33);
            this.province.TabIndex = 7;
            // 
            // phone_num_label
            // 
            this.phone_num_label.AutoSize = true;
            this.phone_num_label.Location = new System.Drawing.Point(552, 419);
            this.phone_num_label.Name = "phone_num_label";
            this.phone_num_label.Size = new System.Drawing.Size(143, 25);
            this.phone_num_label.TabIndex = 22;
            this.phone_num_label.Text = "Phone Numer";
            this.phone_num_label.Click += new System.EventHandler(this.label1_Click);
            // 
            // phone_num
            // 
            this.phone_num.Location = new System.Drawing.Point(708, 413);
            this.phone_num.Name = "phone_num";
            this.phone_num.Size = new System.Drawing.Size(313, 31);
            this.phone_num.TabIndex = 9;
            // 
            // province_label
            // 
            this.province_label.AutoSize = true;
            this.province_label.Location = new System.Drawing.Point(552, 346);
            this.province_label.Name = "province_label";
            this.province_label.Size = new System.Drawing.Size(96, 25);
            this.province_label.TabIndex = 24;
            this.province_label.Text = "Province";
            this.province_label.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // edit_customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 875);
            this.Controls.Add(this.province_label);
            this.Controls.Add(this.phone_num);
            this.Controls.Add(this.phone_num_label);
            this.Controls.Add(this.province);
            this.Controls.Add(this.cust_submit);
            this.Controls.Add(this.post_code);
            this.Controls.Add(this.city);
            this.Controls.Add(this.street_type);
            this.Controls.Add(this.street_name);
            this.Controls.Add(this.building_num);
            this.Controls.Add(this.license_no);
            this.Controls.Add(this.l_name);
            this.Controls.Add(this.f_name);
            this.Controls.Add(this.licence_no_label);
            this.Controls.Add(this.l_name_label);
            this.Controls.Add(this.building_num_label);
            this.Controls.Add(this.street_name_label);
            this.Controls.Add(this.city_label);
            this.Controls.Add(this.post_code_label);
            this.Controls.Add(this.f_name_label);
            this.Controls.Add(this.back_button);
            this.Name = "edit_customer";
            this.Text = "Edit Customer";
            this.Load += new System.EventHandler(this.edit_customer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.Label f_name_label;
        private System.Windows.Forms.Label post_code_label;
        private System.Windows.Forms.Label city_label;
        private System.Windows.Forms.Label street_name_label;
        private System.Windows.Forms.Label building_num_label;
        private System.Windows.Forms.Label l_name_label;
        private System.Windows.Forms.Label licence_no_label;
        private System.Windows.Forms.TextBox f_name;
        private System.Windows.Forms.TextBox l_name;
        private System.Windows.Forms.TextBox license_no;
        private System.Windows.Forms.TextBox building_num;
        private System.Windows.Forms.TextBox street_name;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ComboBox street_type;
        private System.Windows.Forms.TextBox city;
        private System.Windows.Forms.TextBox post_code;
        private System.Windows.Forms.Button cust_submit;
        private System.Windows.Forms.ComboBox province;
        private System.Windows.Forms.Label phone_num_label;
        private System.Windows.Forms.TextBox phone_num;
        private System.Windows.Forms.Label province_label;
    }
}

