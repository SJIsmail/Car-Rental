﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRentalApplication
{
    public partial class edit_vehicle : Form
    {
        database db;
        DataRow row = null;
        public edit_vehicle(database t, DataRow selected)
        {
            db = t;
            row = selected;
            InitializeComponent();
            this.Height = 530;
            this.Width = 885;
            //setting all text boxes to original values pulled from previous form
            plateNumber.Text = row["plate_num"].ToString();
            kms.Text = row["kms"].ToString();
            make.Text = row["make"].ToString();
            model.Text = row["model"].ToString();
            year.Text = row["year"].ToString();
            colour.Text = row["colour"].ToString();
            condition.Text = row["condition"].ToString();
            type_id.Text = row["type_id"].ToString();
            branch_id.Text = row["branch_id"].ToString();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                string command = @"Update Vehicle set kms=" + kms.Text + ", make='" + make.Text.ToUpper() + "', model='" + model.Text.ToUpper() +
                    "', [year]=" + year.Text + ", colour='" + colour.Text.ToUpper() + "', condition=" + condition.Text +
                    ", [type_id]='" + type_id.Text.ToUpper() + "', branch_id='" + branch_id.Text + "' where plate_num = '" + plateNumber.Text + "';";
                db.insert(command);
                MessageBox.Show("Vehicle Information Successfully Updated"); //record updated
                this.Close(); //exit window
            }
            catch
            {
                MessageBox.Show("Invalid Rental Transaction Information");
            }
        }

        private void deleteVehicle_Click(object sender, EventArgs e)
        {
            try
            {
                // sets fields as ToLower to signify deletion as well as condition is set to 0
                string command = @"Update Vehicle set kms=" + kms.Text + ", make='" + make.Text.ToLower() + "', model='" + model.Text.ToLower() +
                    "', [year]=" + year.Text + ", colour='" + colour.Text.ToLower() + "', condition= 0, [type_id]='" + type_id.Text.ToUpper() +
                    "', branch_id='" + branch_id.Text + "' where plate_num = '" + plateNumber.Text + "';";
                db.insert(command);
                MessageBox.Show("Vehicle Successfully Deleted"); //record updated
                this.Close(); //exit window
            }
            catch
            {
                MessageBox.Show("Deletion failed");
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Imsotiredoflabels_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label12341342344_Click(object sender, EventArgs e)
        {

        }

        private void driverNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void plateNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void RTempID_TextChanged(object sender, EventArgs e)
        {

        }

        private void RTbranchID_TextChanged(object sender, EventArgs e)
        {

        }

        private void expectedReturn_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkOutDate_TextChanged(object sender, EventArgs e)
        {

        }

        private void returnCost_TextChanged(object sender, EventArgs e)
        {

        }

        private void lateCost_TextChanged(object sender, EventArgs e)
        {

        }

        private void baseCost_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
