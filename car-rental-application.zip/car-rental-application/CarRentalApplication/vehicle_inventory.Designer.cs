﻿namespace CarRentalApplication
{
    partial class vehicle_inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.modify_vehicle = new System.Windows.Forms.Button();
            this.CreateNewVehicle = new System.Windows.Forms.Button();
            this.LoadVehicleTable = new System.Windows.Forms.Button();
            this.VehicleTable = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.backButton = new System.Windows.Forms.Button();
            this.branch_id = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.VehicleTable)).BeginInit();
            this.SuspendLayout();
            // 
            // modify_vehicle
            // 
            this.modify_vehicle.Location = new System.Drawing.Point(743, 847);
            this.modify_vehicle.Name = "modify_vehicle";
            this.modify_vehicle.Size = new System.Drawing.Size(284, 55);
            this.modify_vehicle.TabIndex = 13;
            this.modify_vehicle.Text = "Modify Vehicle Information";
            this.modify_vehicle.UseVisualStyleBackColor = true;
            this.modify_vehicle.Click += new System.EventHandler(this.modify_vehicle_Click);
            // 
            // CreateNewVehicle
            // 
            this.CreateNewVehicle.Location = new System.Drawing.Point(1302, 847);
            this.CreateNewVehicle.Name = "CreateNewVehicle";
            this.CreateNewVehicle.Size = new System.Drawing.Size(372, 55);
            this.CreateNewVehicle.TabIndex = 11;
            this.CreateNewVehicle.Text = "Add New Vehicle";
            this.CreateNewVehicle.UseVisualStyleBackColor = true;
            this.CreateNewVehicle.Click += new System.EventHandler(this.CreateNewVehicle_Click);
            // 
            // LoadVehicleTable
            // 
            this.LoadVehicleTable.Location = new System.Drawing.Point(1157, 23);
            this.LoadVehicleTable.Name = "LoadVehicleTable";
            this.LoadVehicleTable.Size = new System.Drawing.Size(211, 55);
            this.LoadVehicleTable.TabIndex = 8;
            this.LoadVehicleTable.Text = "Search";
            this.LoadVehicleTable.UseVisualStyleBackColor = true;
            this.LoadVehicleTable.Click += new System.EventHandler(this.LoadVehicleTable_Click);
            // 
            // VehicleTable
            // 
            this.VehicleTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VehicleTable.Location = new System.Drawing.Point(70, 97);
            this.VehicleTable.Name = "VehicleTable";
            this.VehicleTable.ReadOnly = true;
            this.VehicleTable.RowTemplate.Height = 33;
            this.VehicleTable.Size = new System.Drawing.Size(1604, 716);
            this.VehicleTable.TabIndex = 7;
            this.VehicleTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.VehicleTable_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(205, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(380, 51);
            this.label1.TabIndex = 14;
            this.label1.Text = "Branch To Search:";
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(13, 13);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(125, 59);
            this.backButton.TabIndex = 16;
            this.backButton.Text = "< Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // branch_id
            // 
            this.branch_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.branch_id.Location = new System.Drawing.Point(591, 34);
            this.branch_id.Name = "branch_id";
            this.branch_id.Size = new System.Drawing.Size(512, 44);
            this.branch_id.TabIndex = 17;
            // 
            // vehicle_inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1744, 929);
            this.Controls.Add(this.branch_id);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.modify_vehicle);
            this.Controls.Add(this.CreateNewVehicle);
            this.Controls.Add(this.LoadVehicleTable);
            this.Controls.Add(this.VehicleTable);
            this.Name = "vehicle_inventory";
            this.Text = "Vehicle Inventory";
            this.Load += new System.EventHandler(this.vehicle_inventory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.VehicleTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button modify_vehicle;
        private System.Windows.Forms.Button CreateNewVehicle;
        private System.Windows.Forms.Button LoadVehicleTable;
        private System.Windows.Forms.DataGridView VehicleTable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.TextBox branch_id;
    }
}