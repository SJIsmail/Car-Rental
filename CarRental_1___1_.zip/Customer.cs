﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRental
{
	class Customer
	{
		public string DriverNum { get; set; }
		public string FK_StatusID { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string BuildingNum { get; set; }
		public string StreetName { get; set; }
		public string StreetType { get; set; }
		public string City { get; set; }
		public string Province { get; set; }
		public string Postcode { get; set; }
		public string Phone { get; set; }
		public string MembershipDate { get; set; }

		public bool IsGoldMember()
		{
			if (FK_StatusID.Equals("GOLD") == false)
			{
				return false;
			}
			else
			{
				TimeSpan span = DateTime.Now - Convert.ToDateTime(MembershipDate);

				return span.TotalDays <= 365;
			}
		}
	}
}