﻿namespace CarRental
{
	partial class Main
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.CustomerLabel = new System.Windows.Forms.Label();
			this.FirstNameLabel = new System.Windows.Forms.Label();
			this.MLabel = new System.Windows.Forms.Label();
			this.SubmitBtn = new System.Windows.Forms.Button();
			this.ResetBtn = new System.Windows.Forms.Button();
			this.FirstNameBox = new System.Windows.Forms.TextBox();
			this.MBox = new System.Windows.Forms.ComboBox();
			this.DriverNumBox = new System.Windows.Forms.TextBox();
			this.DriverNumLabel = new System.Windows.Forms.Label();
			this.SearchBtn = new System.Windows.Forms.Button();
			this.LastNameLabel = new System.Windows.Forms.Label();
			this.LastNameBox = new System.Windows.Forms.TextBox();
			this.BuildingNumLabel = new System.Windows.Forms.Label();
			this.BuildingNumBox = new System.Windows.Forms.TextBox();
			this.StreetNameLabel = new System.Windows.Forms.Label();
			this.StreetNameBox = new System.Windows.Forms.TextBox();
			this.StreetTypeLabel = new System.Windows.Forms.Label();
			this.StreetTypeBox = new System.Windows.Forms.TextBox();
			this.CityLabel = new System.Windows.Forms.Label();
			this.CityBox = new System.Windows.Forms.TextBox();
			this.ProvinceLabel = new System.Windows.Forms.Label();
			this.ProvinceBox = new System.Windows.Forms.TextBox();
			this.PostcodeLabel = new System.Windows.Forms.Label();
			this.PostcodeBox = new System.Windows.Forms.TextBox();
			this.PhoneLabel = new System.Windows.Forms.Label();
			this.PhoneBox = new System.Windows.Forms.TextBox();
			this.MDateLabel = new System.Windows.Forms.Label();
			this.MDatePicker = new System.Windows.Forms.DateTimePicker();
			this.SuspendLayout();
			// 
			// CustomerLabel
			// 
			this.CustomerLabel.AutoSize = true;
			this.CustomerLabel.Font = new System.Drawing.Font("Consolas", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CustomerLabel.Location = new System.Drawing.Point(127, 11);
			this.CustomerLabel.Name = "CustomerLabel";
			this.CustomerLabel.Size = new System.Drawing.Size(196, 47);
			this.CustomerLabel.TabIndex = 0;
			this.CustomerLabel.Text = "Customer";
			// 
			// FirstNameLabel
			// 
			this.FirstNameLabel.AutoSize = true;
			this.FirstNameLabel.Location = new System.Drawing.Point(58, 174);
			this.FirstNameLabel.Name = "FirstNameLabel";
			this.FirstNameLabel.Size = new System.Drawing.Size(87, 15);
			this.FirstNameLabel.TabIndex = 0;
			this.FirstNameLabel.Text = "First Name";
			// 
			// MLabel
			// 
			this.MLabel.AutoSize = true;
			this.MLabel.Location = new System.Drawing.Point(58, 111);
			this.MLabel.Name = "MLabel";
			this.MLabel.Size = new System.Drawing.Size(87, 15);
			this.MLabel.TabIndex = 0;
			this.MLabel.Text = "Membership";
			// 
			// SubmitBtn
			// 
			this.SubmitBtn.Location = new System.Drawing.Point(138, 433);
			this.SubmitBtn.Name = "SubmitBtn";
			this.SubmitBtn.Size = new System.Drawing.Size(75, 34);
			this.SubmitBtn.TabIndex = 13;
			this.SubmitBtn.Text = "Submit";
			this.SubmitBtn.UseVisualStyleBackColor = true;
			this.SubmitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
			// 
			// ResetBtn
			// 
			this.ResetBtn.Location = new System.Drawing.Point(237, 433);
			this.ResetBtn.Name = "ResetBtn";
			this.ResetBtn.Size = new System.Drawing.Size(75, 34);
			this.ResetBtn.TabIndex = 14;
			this.ResetBtn.Text = "Reset";
			this.ResetBtn.UseVisualStyleBackColor = true;
			this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
			// 
			// FirstNameBox
			// 
			this.FirstNameBox.Location = new System.Drawing.Point(154, 169);
			this.FirstNameBox.Name = "FirstNameBox";
			this.FirstNameBox.Size = new System.Drawing.Size(97, 25);
			this.FirstNameBox.TabIndex = 4;
			// 
			// MBox
			// 
			this.MBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.MBox.FormattingEnabled = true;
			this.MBox.Location = new System.Drawing.Point(154, 107);
			this.MBox.Name = "MBox";
			this.MBox.Size = new System.Drawing.Size(286, 23);
			this.MBox.TabIndex = 2;
			// 
			// DriverNumBox
			// 
			this.DriverNumBox.Location = new System.Drawing.Point(154, 75);
			this.DriverNumBox.Name = "DriverNumBox";
			this.DriverNumBox.Size = new System.Drawing.Size(205, 25);
			this.DriverNumBox.TabIndex = 1;
			// 
			// DriverNumLabel
			// 
			this.DriverNumLabel.AutoSize = true;
			this.DriverNumLabel.Location = new System.Drawing.Point(58, 80);
			this.DriverNumLabel.Name = "DriverNumLabel";
			this.DriverNumLabel.Size = new System.Drawing.Size(87, 15);
			this.DriverNumLabel.TabIndex = 0;
			this.DriverNumLabel.Text = "Driver Num";
			// 
			// SearchBtn
			// 
			this.SearchBtn.Location = new System.Drawing.Point(365, 75);
			this.SearchBtn.Name = "SearchBtn";
			this.SearchBtn.Size = new System.Drawing.Size(75, 25);
			this.SearchBtn.TabIndex = 2;
			this.SearchBtn.Text = "Search";
			this.SearchBtn.UseVisualStyleBackColor = true;
			this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
			// 
			// LastNameLabel
			// 
			this.LastNameLabel.AutoSize = true;
			this.LastNameLabel.Location = new System.Drawing.Point(258, 174);
			this.LastNameLabel.Name = "LastNameLabel";
			this.LastNameLabel.Size = new System.Drawing.Size(79, 15);
			this.LastNameLabel.TabIndex = 0;
			this.LastNameLabel.Text = "Last Name";
			// 
			// LastNameBox
			// 
			this.LastNameBox.Location = new System.Drawing.Point(343, 169);
			this.LastNameBox.Name = "LastNameBox";
			this.LastNameBox.Size = new System.Drawing.Size(97, 25);
			this.LastNameBox.TabIndex = 5;
			// 
			// BuildingNumLabel
			// 
			this.BuildingNumLabel.AutoSize = true;
			this.BuildingNumLabel.Location = new System.Drawing.Point(42, 206);
			this.BuildingNumLabel.Name = "BuildingNumLabel";
			this.BuildingNumLabel.Size = new System.Drawing.Size(103, 15);
			this.BuildingNumLabel.TabIndex = 0;
			this.BuildingNumLabel.Text = "Building No.";
			// 
			// BuildingNumBox
			// 
			this.BuildingNumBox.Location = new System.Drawing.Point(154, 201);
			this.BuildingNumBox.Name = "BuildingNumBox";
			this.BuildingNumBox.Size = new System.Drawing.Size(286, 25);
			this.BuildingNumBox.TabIndex = 6;
			// 
			// StreetNameLabel
			// 
			this.StreetNameLabel.AutoSize = true;
			this.StreetNameLabel.Location = new System.Drawing.Point(50, 238);
			this.StreetNameLabel.Name = "StreetNameLabel";
			this.StreetNameLabel.Size = new System.Drawing.Size(95, 15);
			this.StreetNameLabel.TabIndex = 0;
			this.StreetNameLabel.Text = "Street Name";
			// 
			// StreetNameBox
			// 
			this.StreetNameBox.Location = new System.Drawing.Point(154, 233);
			this.StreetNameBox.Name = "StreetNameBox";
			this.StreetNameBox.Size = new System.Drawing.Size(286, 25);
			this.StreetNameBox.TabIndex = 7;
			// 
			// StreetTypeLabel
			// 
			this.StreetTypeLabel.AutoSize = true;
			this.StreetTypeLabel.Location = new System.Drawing.Point(50, 270);
			this.StreetTypeLabel.Name = "StreetTypeLabel";
			this.StreetTypeLabel.Size = new System.Drawing.Size(95, 15);
			this.StreetTypeLabel.TabIndex = 0;
			this.StreetTypeLabel.Text = "Street Type";
			// 
			// StreetTypeBox
			// 
			this.StreetTypeBox.Location = new System.Drawing.Point(154, 265);
			this.StreetTypeBox.Name = "StreetTypeBox";
			this.StreetTypeBox.Size = new System.Drawing.Size(286, 25);
			this.StreetTypeBox.TabIndex = 8;
			// 
			// CityLabel
			// 
			this.CityLabel.AutoSize = true;
			this.CityLabel.Location = new System.Drawing.Point(106, 302);
			this.CityLabel.Name = "CityLabel";
			this.CityLabel.Size = new System.Drawing.Size(39, 15);
			this.CityLabel.TabIndex = 0;
			this.CityLabel.Text = "City";
			// 
			// CityBox
			// 
			this.CityBox.Location = new System.Drawing.Point(154, 297);
			this.CityBox.Name = "CityBox";
			this.CityBox.Size = new System.Drawing.Size(286, 25);
			this.CityBox.TabIndex = 9;
			// 
			// ProvinceLabel
			// 
			this.ProvinceLabel.AutoSize = true;
			this.ProvinceLabel.Location = new System.Drawing.Point(74, 334);
			this.ProvinceLabel.Name = "ProvinceLabel";
			this.ProvinceLabel.Size = new System.Drawing.Size(71, 15);
			this.ProvinceLabel.TabIndex = 0;
			this.ProvinceLabel.Text = "Province";
			// 
			// ProvinceBox
			// 
			this.ProvinceBox.Location = new System.Drawing.Point(154, 329);
			this.ProvinceBox.Name = "ProvinceBox";
			this.ProvinceBox.Size = new System.Drawing.Size(286, 25);
			this.ProvinceBox.TabIndex = 10;
			// 
			// PostcodeLabel
			// 
			this.PostcodeLabel.AutoSize = true;
			this.PostcodeLabel.Location = new System.Drawing.Point(74, 366);
			this.PostcodeLabel.Name = "PostcodeLabel";
			this.PostcodeLabel.Size = new System.Drawing.Size(71, 15);
			this.PostcodeLabel.TabIndex = 0;
			this.PostcodeLabel.Text = "Postcode";
			// 
			// PostcodeBox
			// 
			this.PostcodeBox.Location = new System.Drawing.Point(154, 361);
			this.PostcodeBox.Name = "PostcodeBox";
			this.PostcodeBox.Size = new System.Drawing.Size(286, 25);
			this.PostcodeBox.TabIndex = 11;
			// 
			// PhoneLabel
			// 
			this.PhoneLabel.AutoSize = true;
			this.PhoneLabel.Location = new System.Drawing.Point(98, 398);
			this.PhoneLabel.Name = "PhoneLabel";
			this.PhoneLabel.Size = new System.Drawing.Size(47, 15);
			this.PhoneLabel.TabIndex = 0;
			this.PhoneLabel.Text = "Phone";
			// 
			// PhoneBox
			// 
			this.PhoneBox.Location = new System.Drawing.Point(154, 393);
			this.PhoneBox.Name = "PhoneBox";
			this.PhoneBox.Size = new System.Drawing.Size(286, 25);
			this.PhoneBox.TabIndex = 12;
			// 
			// MDateLabel
			// 
			this.MDateLabel.AutoSize = true;
			this.MDateLabel.Location = new System.Drawing.Point(18, 142);
			this.MDateLabel.Name = "MDateLabel";
			this.MDateLabel.Size = new System.Drawing.Size(127, 15);
			this.MDateLabel.TabIndex = 0;
			this.MDateLabel.Text = "Membership Date";
			// 
			// MDatePicker
			// 
			this.MDatePicker.Location = new System.Drawing.Point(154, 137);
			this.MDatePicker.Name = "MDatePicker";
			this.MDatePicker.Size = new System.Drawing.Size(286, 25);
			this.MDatePicker.TabIndex = 3;
			// 
			// Main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(450, 478);
			this.Controls.Add(this.DriverNumLabel);
			this.Controls.Add(this.DriverNumBox);
			this.Controls.Add(this.MDatePicker);
			this.Controls.Add(this.MBox);
			this.Controls.Add(this.LastNameBox);
			this.Controls.Add(this.PhoneBox);
			this.Controls.Add(this.PostcodeBox);
			this.Controls.Add(this.ProvinceBox);
			this.Controls.Add(this.CityBox);
			this.Controls.Add(this.StreetTypeBox);
			this.Controls.Add(this.StreetNameBox);
			this.Controls.Add(this.BuildingNumBox);
			this.Controls.Add(this.FirstNameBox);
			this.Controls.Add(this.ResetBtn);
			this.Controls.Add(this.SearchBtn);
			this.Controls.Add(this.SubmitBtn);
			this.Controls.Add(this.MDateLabel);
			this.Controls.Add(this.MLabel);
			this.Controls.Add(this.LastNameLabel);
			this.Controls.Add(this.PhoneLabel);
			this.Controls.Add(this.PostcodeLabel);
			this.Controls.Add(this.ProvinceLabel);
			this.Controls.Add(this.CityLabel);
			this.Controls.Add(this.StreetTypeLabel);
			this.Controls.Add(this.StreetNameLabel);
			this.Controls.Add(this.BuildingNumLabel);
			this.Controls.Add(this.FirstNameLabel);
			this.Controls.Add(this.CustomerLabel);
			this.Name = "Main";
			this.Text = "Main";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label CustomerLabel;
		private System.Windows.Forms.Label FirstNameLabel;
		private System.Windows.Forms.Label MLabel;
		private System.Windows.Forms.Button SubmitBtn;
		private System.Windows.Forms.Button ResetBtn;
		private System.Windows.Forms.TextBox FirstNameBox;
		private System.Windows.Forms.ComboBox MBox;
		private System.Windows.Forms.TextBox DriverNumBox;
		private System.Windows.Forms.Label DriverNumLabel;
		private System.Windows.Forms.Button SearchBtn;
		private System.Windows.Forms.Label LastNameLabel;
		private System.Windows.Forms.TextBox LastNameBox;
		private System.Windows.Forms.Label BuildingNumLabel;
		private System.Windows.Forms.TextBox BuildingNumBox;
		private System.Windows.Forms.Label StreetNameLabel;
		private System.Windows.Forms.TextBox StreetNameBox;
		private System.Windows.Forms.Label StreetTypeLabel;
		private System.Windows.Forms.TextBox StreetTypeBox;
		private System.Windows.Forms.Label CityLabel;
		private System.Windows.Forms.TextBox CityBox;
		private System.Windows.Forms.Label ProvinceLabel;
		private System.Windows.Forms.TextBox ProvinceBox;
		private System.Windows.Forms.Label PostcodeLabel;
		private System.Windows.Forms.TextBox PostcodeBox;
		private System.Windows.Forms.Label PhoneLabel;
		private System.Windows.Forms.TextBox PhoneBox;
		private System.Windows.Forms.Label MDateLabel;
		private System.Windows.Forms.DateTimePicker MDatePicker;
	}
}