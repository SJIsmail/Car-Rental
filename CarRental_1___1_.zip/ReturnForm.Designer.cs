﻿namespace CarRental
{
	partial class ReturnForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.CustomerLabel = new System.Windows.Forms.Label();
			this.TIDLabel = new System.Windows.Forms.Label();
			this.TIDBox = new System.Windows.Forms.TextBox();
			this.SearchTIDBtn = new System.Windows.Forms.Button();
			this.EIDBox = new System.Windows.Forms.TextBox();
			this.EIDLabel = new System.Windows.Forms.Label();
			this.BIDBox = new System.Windows.Forms.TextBox();
			this.BIDLabel = new System.Windows.Forms.Label();
			this.FeesLabel = new System.Windows.Forms.Label();
			this.SaveBtn = new System.Windows.Forms.Button();
			this.ResetBtn = new System.Windows.Forms.Button();
			this.BaseCostBox = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.LateCostBox = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.ReturnCostBox = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.CalculateBtn = new System.Windows.Forms.Button();
			this.FeesBox = new System.Windows.Forms.RichTextBox();
			this.SuspendLayout();
			// 
			// CustomerLabel
			// 
			this.CustomerLabel.AutoSize = true;
			this.CustomerLabel.Font = new System.Drawing.Font("Consolas", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CustomerLabel.Location = new System.Drawing.Point(126, 9);
			this.CustomerLabel.Name = "CustomerLabel";
			this.CustomerLabel.Size = new System.Drawing.Size(152, 47);
			this.CustomerLabel.TabIndex = 0;
			this.CustomerLabel.Text = "Return";
			// 
			// TIDLabel
			// 
			this.TIDLabel.AutoSize = true;
			this.TIDLabel.Location = new System.Drawing.Point(8, 64);
			this.TIDLabel.Name = "TIDLabel";
			this.TIDLabel.Size = new System.Drawing.Size(95, 15);
			this.TIDLabel.TabIndex = 0;
			this.TIDLabel.Text = "Transaction";
			// 
			// TIDBox
			// 
			this.TIDBox.Location = new System.Drawing.Point(111, 59);
			this.TIDBox.Name = "TIDBox";
			this.TIDBox.Size = new System.Drawing.Size(205, 25);
			this.TIDBox.TabIndex = 1;
			// 
			// SearchTIDBtn
			// 
			this.SearchTIDBtn.Location = new System.Drawing.Point(322, 90);
			this.SearchTIDBtn.Name = "SearchTIDBtn";
			this.SearchTIDBtn.Size = new System.Drawing.Size(75, 25);
			this.SearchTIDBtn.TabIndex = 3;
			this.SearchTIDBtn.Text = "Search";
			this.SearchTIDBtn.UseVisualStyleBackColor = true;
			this.SearchTIDBtn.Click += new System.EventHandler(this.SearchTIDBtn_Click);
			// 
			// EIDBox
			// 
			this.EIDBox.Location = new System.Drawing.Point(111, 90);
			this.EIDBox.Name = "EIDBox";
			this.EIDBox.Size = new System.Drawing.Size(205, 25);
			this.EIDBox.TabIndex = 2;
			// 
			// EIDLabel
			// 
			this.EIDLabel.AutoSize = true;
			this.EIDLabel.Location = new System.Drawing.Point(32, 95);
			this.EIDLabel.Name = "EIDLabel";
			this.EIDLabel.Size = new System.Drawing.Size(71, 15);
			this.EIDLabel.TabIndex = 0;
			this.EIDLabel.Text = "Employee";
			// 
			// BIDBox
			// 
			this.BIDBox.Location = new System.Drawing.Point(111, 121);
			this.BIDBox.Name = "BIDBox";
			this.BIDBox.ReadOnly = true;
			this.BIDBox.Size = new System.Drawing.Size(205, 25);
			this.BIDBox.TabIndex = 0;
			// 
			// BIDLabel
			// 
			this.BIDLabel.AutoSize = true;
			this.BIDLabel.Location = new System.Drawing.Point(48, 126);
			this.BIDLabel.Name = "BIDLabel";
			this.BIDLabel.Size = new System.Drawing.Size(55, 15);
			this.BIDLabel.TabIndex = 0;
			this.BIDLabel.Text = "Branch";
			// 
			// FeesLabel
			// 
			this.FeesLabel.AutoSize = true;
			this.FeesLabel.Location = new System.Drawing.Point(64, 250);
			this.FeesLabel.Name = "FeesLabel";
			this.FeesLabel.Size = new System.Drawing.Size(39, 15);
			this.FeesLabel.TabIndex = 0;
			this.FeesLabel.Text = "Fees";
			// 
			// SaveBtn
			// 
			this.SaveBtn.Location = new System.Drawing.Point(165, 369);
			this.SaveBtn.Name = "SaveBtn";
			this.SaveBtn.Size = new System.Drawing.Size(75, 38);
			this.SaveBtn.TabIndex = 6;
			this.SaveBtn.Text = "Save";
			this.SaveBtn.UseVisualStyleBackColor = true;
			this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
			// 
			// ResetBtn
			// 
			this.ResetBtn.Location = new System.Drawing.Point(246, 369);
			this.ResetBtn.Name = "ResetBtn";
			this.ResetBtn.Size = new System.Drawing.Size(75, 38);
			this.ResetBtn.TabIndex = 7;
			this.ResetBtn.Text = "Reset";
			this.ResetBtn.UseVisualStyleBackColor = true;
			this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
			// 
			// BaseCostBox
			// 
			this.BaseCostBox.Location = new System.Drawing.Point(111, 152);
			this.BaseCostBox.Name = "BaseCostBox";
			this.BaseCostBox.ReadOnly = true;
			this.BaseCostBox.Size = new System.Drawing.Size(205, 25);
			this.BaseCostBox.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(24, 157);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(79, 15);
			this.label1.TabIndex = 0;
			this.label1.Text = "Base Cost";
			// 
			// LateCostBox
			// 
			this.LateCostBox.Location = new System.Drawing.Point(111, 183);
			this.LateCostBox.Name = "LateCostBox";
			this.LateCostBox.ReadOnly = true;
			this.LateCostBox.Size = new System.Drawing.Size(205, 25);
			this.LateCostBox.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(24, 188);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(79, 15);
			this.label2.TabIndex = 0;
			this.label2.Text = "Late Cost";
			// 
			// ReturnCostBox
			// 
			this.ReturnCostBox.Location = new System.Drawing.Point(111, 214);
			this.ReturnCostBox.Name = "ReturnCostBox";
			this.ReturnCostBox.ReadOnly = true;
			this.ReturnCostBox.Size = new System.Drawing.Size(205, 25);
			this.ReturnCostBox.TabIndex = 0;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(8, 219);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(95, 15);
			this.label3.TabIndex = 0;
			this.label3.Text = "Return Cost";
			// 
			// CalculateBtn
			// 
			this.CalculateBtn.Location = new System.Drawing.Point(84, 369);
			this.CalculateBtn.Name = "CalculateBtn";
			this.CalculateBtn.Size = new System.Drawing.Size(75, 38);
			this.CalculateBtn.TabIndex = 5;
			this.CalculateBtn.Text = "Calc";
			this.CalculateBtn.UseVisualStyleBackColor = true;
			this.CalculateBtn.Click += new System.EventHandler(this.CalculateBtn_Click);
			// 
			// FeesBox
			// 
			this.FeesBox.Location = new System.Drawing.Point(111, 246);
			this.FeesBox.Name = "FeesBox";
			this.FeesBox.Size = new System.Drawing.Size(205, 117);
			this.FeesBox.TabIndex = 8;
			this.FeesBox.Text = "";
			// 
			// ReturnForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(405, 417);
			this.Controls.Add(this.FeesBox);
			this.Controls.Add(this.ResetBtn);
			this.Controls.Add(this.CalculateBtn);
			this.Controls.Add(this.SaveBtn);
			this.Controls.Add(this.FeesLabel);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.BIDLabel);
			this.Controls.Add(this.EIDLabel);
			this.Controls.Add(this.TIDLabel);
			this.Controls.Add(this.ReturnCostBox);
			this.Controls.Add(this.LateCostBox);
			this.Controls.Add(this.BaseCostBox);
			this.Controls.Add(this.BIDBox);
			this.Controls.Add(this.EIDBox);
			this.Controls.Add(this.TIDBox);
			this.Controls.Add(this.SearchTIDBtn);
			this.Controls.Add(this.CustomerLabel);
			this.Name = "ReturnForm";
			this.Text = "ReturnForm";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ReturnForm_FormClosing);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label CustomerLabel;
		private System.Windows.Forms.Label TIDLabel;
		private System.Windows.Forms.TextBox TIDBox;
		private System.Windows.Forms.Button SearchTIDBtn;
		private System.Windows.Forms.TextBox EIDBox;
		private System.Windows.Forms.Label EIDLabel;
		private System.Windows.Forms.TextBox BIDBox;
		private System.Windows.Forms.Label BIDLabel;
		private System.Windows.Forms.Label FeesLabel;
		private System.Windows.Forms.Button SaveBtn;
		private System.Windows.Forms.Button ResetBtn;
		private System.Windows.Forms.TextBox BaseCostBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox LateCostBox;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox ReturnCostBox;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button CalculateBtn;
		private System.Windows.Forms.RichTextBox FeesBox;
	}
}