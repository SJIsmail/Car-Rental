﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CarRental
{
	class Database
	{
		SqlConnection mConnection;//创建连接通道

		public Database()
		{
			mConnection = new SqlConnection("server=localhost;database=CarRentalDatabase;Trusted_Connection=SSPI");
		}

		public void Open()
		{
			try
			{
				mConnection.Open();
			}
			catch (Exception exception)
			{
				MessageBox.Show(exception.ToString());
			}
		}

		public void WriteReturn(Return R)
		{
			ArrayList ReturnList = ExecuteQuery("select * from Returns where transaction_id = " + R.FK_TransactionID);

			if (ReturnList.Count != 0)
			{
				string sql = @"update Returns set " +
					"emp_id = '" + R.EmployeeID + "', " +
					"branch_id = '" + R.BranchID + "', " +
					"return_date = '" + R.ReturnDate + "', " +
					"fees_paid = " + R.Fees + " " +
					"where transaction_id = '" + R.FK_TransactionID + "'";

				ExecuteNonQuery(sql);
			}
			else
			{
				string sql = @"insert into Returns values (" +
					"'" + R.FK_TransactionID + "', " +
					"'" + R.EmployeeID + "', " +
					"'" + R.BranchID + "', " +
					"'" + R.ReturnDate + "', " +
					"" + R.Fees + ")";

				ExecuteNonQuery(sql);
			}
		}

		public List<string> GetMembership()
		{
			ArrayList RawList = ExecuteQuery("select distinct status_id from Membership");

			List<string> MembershipList = new List<string>();

			foreach (ArrayList item in RawList)
			{
				MembershipList.Add(Convert.ToString(item[0]));
			}

			return MembershipList;
		}

		public void SetCustomer(Customer C)
		{
			string sql = @"update Customer set " +
				"status_id = '" + C.FK_StatusID + "', " +
				"f_name = '" + C.FirstName + "', " +
				"l_name = '" + C.LastName + "', " +
				"building_num = '" + C.BuildingNum + "', " +
				"street_name = '" + C.StreetName + "', " +
				"street_type = '" + C.StreetType + "', " +
				"city = '" + C.City + "', " +
				"province = '" + C.Province + "', " +
				"post_code = '" + C.Postcode + "', " +
				"phone_num = '" + C.Phone + "', " +
				"membership_date = '" + C.MembershipDate + "' " +
				"where driver_num = '" + C.DriverNum + "'";

			ExecuteNonQuery(sql);
		}

		public Transaction GetTransaction(string TransactionID)
		{
			ArrayList TransactionList = ExecuteQuery("select * from Rental_Transaction where transaction_id = '" + TransactionID + "'");

			if (TransactionList.Count != 0)
			{
				ArrayList RawData = (ArrayList)TransactionList[0];

				Transaction T = new Transaction();
				T.ID = Convert.ToString(RawData[0]);
				T.BaseCost = Convert.ToDouble(RawData[1]);
				T.LateCost = Convert.ToDouble(RawData[2]);
				T.ReturnCost = Convert.ToDouble(RawData[3]);
				T.CheckoutDate = (DateTime)RawData[4];
				T.ExpectedReturnDate = (DateTime)RawData[5];
				T.FK_BranchID = Convert.ToString(RawData[6]);
				T.FK_EmployeeID = Convert.ToString(RawData[7]);
				T.FK_PlateNum = Convert.ToString(RawData[8]);
				T.FK_DriverNum = Convert.ToString(RawData[9]);

				return T;
			}

			return null;
		}

		public Employee GetEmployee(string EmployeeID)
		{
			ArrayList EmployeeList = ExecuteQuery("select * from Employee where emp_id = '" + EmployeeID + "'");

			if (EmployeeList.Count != 0)
			{
				ArrayList RawData = (ArrayList)EmployeeList[0];

				Employee E = new Employee();
				E.ID = Convert.ToString(RawData[0]);
				E.FirstName = Convert.ToString(RawData[1]);
				E.LastName = Convert.ToString(RawData[2]);
				E.Position = Convert.ToString(RawData[3]);
				E.HireDate = (DateTime)RawData[4];
				E.HourWage = Convert.ToInt32(RawData[5]);
				E.FK_BranchID = Convert.ToString(RawData[6]);
				E.BranchDate = (DateTime)RawData[7];

				return E;
			}

			return null;
		}

		public Customer GetCustomer(string DriverNum)
		{
			ArrayList CustomerList = ExecuteQuery("select * from Customer where driver_num = '" + DriverNum + "'");

			if (CustomerList.Count != 0)
			{
				ArrayList RawData = (ArrayList)CustomerList[0];

				Customer C = new Customer();
				C.DriverNum = Convert.ToString(RawData[0]);
				C.FK_StatusID = Convert.ToString(RawData[1]);
				C.FirstName = Convert.ToString(RawData[2]);
				C.LastName = Convert.ToString(RawData[3]);
				C.BuildingNum = Convert.ToString(RawData[4]);
				C.StreetName = Convert.ToString(RawData[5]);
				C.StreetType = Convert.ToString(RawData[6]);
				C.City = Convert.ToString(RawData[7]);
				C.Province = Convert.ToString(RawData[8]);
				C.Postcode = Convert.ToString(RawData[9]);
				C.Phone = Convert.ToString(RawData[10]);
				C.MembershipDate = Convert.ToString(RawData[11]);

				return C;
			}

			return null;
		}

		private int ExecuteNonQuery(string sql)
		{
			return new SqlCommand(sql, mConnection).ExecuteNonQuery();
		}

		private ArrayList ExecuteQuery(string sql)
		{
			ArrayList queriedList = new ArrayList();

			SqlCommand command = new SqlCommand();
			command.Connection = mConnection;
			command.CommandType = CommandType.Text;
			command.CommandText = sql;
			SqlDataReader reader = command.ExecuteReader();     //执行SQL，返回一个“流”
			while (reader.Read())
			{
				int columns = reader.VisibleFieldCount;
				ArrayList tempList = new ArrayList();

				for (int i = 0; i < columns; i++)
				{
					tempList.Add(reader[i]);
				}

				queriedList.Add(tempList);
			}
			reader.Close();

			return queriedList;
		}

		public void Close()
		{
			mConnection.Close();
		}
	}
}