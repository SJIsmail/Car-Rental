﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRental
{
	class Return
	{
		public string FK_TransactionID { get; set; }
		public string EmployeeID { get; set; }
		public string BranchID { get; set; }
		public DateTime ReturnDate { get; set; }
		public double Fees { get; set; }
	}
}