﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CarRental
{
	public partial class Main : Form
	{
		Database mDB = new Database();

		Customer mCustomer = new Customer();

		public Main()
		{
			InitializeComponent();
			StartPosition = FormStartPosition.CenterScreen;

			mDB.Open();

			List<string> MList = mDB.GetMembership();
			MBox.Items.Clear();
			MBox.Items.AddRange(MList.ToArray());
		}

		private void SearchBtn_Click(object sender, EventArgs e)
		{
			mCustomer = mDB.GetCustomer(DriverNumBox.Text);

			if (mCustomer != null)
			{
				SetUI();
			}
			else
			{
				MessageBox.Show("No customer found with the specified Driver Number.");
			}
		}

		private void SetCustomer()
		{
			mCustomer.FK_StatusID = MBox.Text;
			mCustomer.FirstName = FirstNameBox.Text;
			mCustomer.LastName = LastNameBox.Text;
			mCustomer.BuildingNum = BuildingNumBox.Text;
			mCustomer.StreetName = StreetNameBox.Text;
			mCustomer.StreetType = StreetTypeBox.Text;
			mCustomer.City = CityBox.Text;
			mCustomer.Province = ProvinceBox.Text;
			mCustomer.Postcode = PostcodeBox.Text;
			mCustomer.Phone = PhoneBox.Text;
			mCustomer.MembershipDate = MDatePicker.Value.ToString();
		}

		private void SetUI()
		{
			DriverNumBox.Text = mCustomer.DriverNum;
			MBox.Text = mCustomer.IsGoldMember() ? "GOLD" : "BRONZE";

			if (mCustomer.MembershipDate.Length != 0)
				MDatePicker.Value = Convert.ToDateTime(mCustomer.MembershipDate);

			FirstNameBox.Text = mCustomer.FirstName;
			LastNameBox.Text = mCustomer.LastName;
			BuildingNumBox.Text = mCustomer.BuildingNum;
			StreetNameBox.Text = mCustomer.StreetName;
			StreetTypeBox.Text = mCustomer.StreetType;
			CityBox.Text = mCustomer.City;
			ProvinceBox.Text = mCustomer.Province;
			PostcodeBox.Text = mCustomer.Postcode;
			PhoneBox.Text = mCustomer.Phone;
		}

		private void SubmitBtn_Click(object sender, EventArgs e)
		{
			SetCustomer();
			mDB.SetCustomer(mCustomer);
		}

		private void ResetBtn_Click(object sender, EventArgs e)
		{
			DriverNumBox.Text = "";
			MBox.SelectedIndex = 0;
			MDatePicker.Value = DateTime.Now;
			FirstNameBox.Text = "";
			LastNameBox.Text = "";
			BuildingNumBox.Text = "";
			StreetNameBox.Text = "";
			StreetTypeBox.Text = "";
			CityBox.Text = "";
			ProvinceBox.Text = "";
			PostcodeBox.Text = "";
			PhoneBox.Text = "";
		}

		private void Main_FormClosing(object sender, FormClosingEventArgs e)
		{
			mDB.Close();
		}
	}
}
