﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRental
{
	class Employee
	{
		public string ID { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Position { get; set; }
		public DateTime HireDate { get; set; }
		public int HourWage { get; set; }
		public string FK_BranchID { get; set; }
		public DateTime BranchDate { get; set; }
	}
}